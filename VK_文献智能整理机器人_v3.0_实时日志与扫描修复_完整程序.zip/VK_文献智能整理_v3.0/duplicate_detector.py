# -*- coding: utf-8 -*-
"""Persistent, cautious first-ten-page PDF duplicate detection (stdlib + PyMuPDF)."""
import datetime
import hashlib
import json
import re
import sqlite3
from pathlib import Path

SCHEMA = '''CREATE TABLE IF NOT EXISTS books (
 path TEXT PRIMARY KEY, pages INTEGER NOT NULL, size INTEGER NOT NULL,
 modified_ns INTEGER NOT NULL, first_ten TEXT NOT NULL, scanned_at TEXT NOT NULL
)'''


def normalize(s):
    return re.sub(r'[^\w\u0400-\u052f]+', '', (s or '').casefold(), flags=re.UNICODE)


def image_dhash(page):
    # 9x8 grayscale sampling. Image hash complements text extraction for scanned PDFs.
    import fitz
    pix = page.get_pixmap(matrix=fitz.Matrix(.27, .27), colorspace=fitz.csGRAY, alpha=False)
    w, h = pix.width, pix.height
    if w < 9 or h < 8:
        return None
    data = pix.samples
    bits = 0
    for y in range(8):
        yy = min(h - 1, int((y + .5) * h / 8))
        prev = None
        for x in range(9):
            xx = min(w - 1, int((x + .5) * w / 9))
            v = data[yy * pix.stride + xx]
            if prev is not None:
                bits = (bits << 1) | (1 if prev > v else 0)
            prev = v
    # Exact rendered-page pixel digest helps with scanned PDFs where dHash is too weak.
    return '%016x' % bits, hashlib.sha256(pix.samples).hexdigest()


def fingerprint_pdf(path):
    import fitz
    result = []
    with fitz.open(str(path)) as doc:
        if doc.is_encrypted:
            raise ValueError('PDF 已加密')
        for i in range(min(len(doc), 10)):
            page = doc[i]
            txt = normalize(page.get_text('text'))
            # Text hash only for substantive text; blank title pages cannot prove duplicates.
            th = hashlib.sha256(txt.encode('utf-8')).hexdigest() if len(txt) >= 40 else ''
            dh, pixels = image_dhash(page)
            result.append({'text': th, 'image': dh, 'pixels': pixels, 'characters': len(txt)})
        return {'pages': len(doc), 'first_ten': result}


def compare(a, b):
    """Return evidence score and label; never automatically delete originals."""
    aa, bb = a['first_ten'], b['first_ten']
    if min(len(aa), len(bb)) < 3:
        return 0.0, ''
    page_ratio = min(a['pages'], b['pages']) / max(a['pages'], b['pages'], 1)
    if page_ratio < .90:
        return 0.0, ''
    best = 0.0
    for offset in (-2, -1, 0, 1, 2):
        comparable = [(aa[i], bb[i + offset]) for i in range(len(aa))
                      if 0 <= i + offset < len(bb)]
        if len(comparable) < 3:
            continue
        score = 0.0
        meaningful = 0
        exact_text = 0
        image_matches = 0
        for x, y in comparable:
            if x['text'] and y['text']:
                meaningful += 1
                if x['text'] == y['text']:
                    exact_text += 1
                    score += 1
            elif x.get('pixels') and x.get('pixels') == y.get('pixels'):
                meaningful += 1
                image_matches += 1
                score += 1
            elif x['image'] and y['image']:
                # Nearly all-white images have hash 0 and aren't informative.
                hx, hy = int(x['image'], 16), int(y['image'], 16)
                if hx == 0 and hy == 0:
                    continue
                meaningful += 1
                distance = (hx ^ hy).bit_count()
                if distance <= 4:
                    image_matches += 1
                    score += .9
                elif distance <= 8:
                    score += .6
        if meaningful >= 3 and (exact_text >= 3 or image_matches >= 3):
            best = max(best, score / meaningful)
    if best >= .87:
        return round(best, 3), '高度相似'
    if best >= .70:
        return round(best, 3), '疑似相似'
    return 0.0, ''


class Index:
    def __init__(self, dbfile):
        self.dbfile = Path(dbfile)
        self.dbfile.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(str(self.dbfile))
        self.db.execute(SCHEMA)
        self.db.commit()

    def close(self):
        self.db.close()

    def get_or_scan(self, path):
        path = Path(path).resolve()
        stat = path.stat()
        old = self.db.execute('SELECT pages,size,modified_ns,first_ten FROM books WHERE path=?', (str(path),)).fetchone()
        if old and old[1] == stat.st_size and old[2] == stat.st_mtime_ns:
            return {'pages': old[0], 'first_ten': json.loads(old[3])}
        fp = fingerprint_pdf(path)
        self.db.execute('INSERT OR REPLACE INTO books VALUES (?,?,?,?,?,?)',
                        (str(path), fp['pages'], stat.st_size, stat.st_mtime_ns,
                         json.dumps(fp['first_ten'], ensure_ascii=False), datetime.datetime.now().isoformat()))
        self.db.commit()
        return fp

    def search(self, path, fp):
        matches = []
        for other, pages, serialized in self.db.execute('SELECT path,pages,first_ten FROM books'):
            if other.casefold() == str(Path(path).resolve()).casefold():
                continue
            score, label = compare(fp, {'pages': pages, 'first_ten': json.loads(serialized)})
            if label:
                matches.append((score, label, other, Path(other).is_file()))
        # Prefer extant originals over old historical references.
        return sorted(matches, key=lambda item: (item[3], item[0]), reverse=True)

    def moved(self, src, dest):
        old = str(Path(src).resolve())
        new = str(Path(dest).resolve())
        stat = Path(dest).stat()
        self.db.execute('UPDATE books SET path=?,size=?,modified_ns=? WHERE path=?',
                        (new, stat.st_size, stat.st_mtime_ns, old))
        self.db.commit()
