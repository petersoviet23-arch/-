﻿$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$tess='C:\Program Files\Tesseract-OCR\tesseract.exe'
if(-not (Test-Path $tess)){
  $cmd=Get-Command tesseract.exe -ErrorAction SilentlyContinue
  if($cmd){$tess=$cmd.Source}else{throw 'Tesseract.exe not found'}
}
$data=Join-Path $env:LOCALAPPDATA 'VKLibraryOrganizer\OCR\tessdata'
New-Item -ItemType Directory -Force -Path $data | Out-Null
foreach($lang in @('rus','eng')){
  $dest=Join-Path $data ($lang+'.traineddata')
  if(-not (Test-Path $dest) -or (Get-Item $dest).Length -lt 100000){
    $native=Join-Path (Split-Path -Parent $tess) ('tessdata\'+$lang+'.traineddata')
    if(Test-Path $native){Copy-Item $native $dest -Force}
  }
  if(-not (Test-Path $dest) -or (Get-Item $dest).Length -lt 100000){
    $url='https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/'+$lang+'.traineddata'
    Write-Host ('Downloading OCR '+$lang)
    Invoke-WebRequest -Uri $url -OutFile ($dest+'.tmp') -UseBasicParsing -TimeoutSec 180
    if((Get-Item ($dest+'.tmp')).Length -lt 100000){throw ('Bad file: '+$lang)}
    Move-Item ($dest+'.tmp') $dest -Force
  }
}
[Environment]::SetEnvironmentVariable('TESSDATA_PREFIX',$data,'User')
$env:TESSDATA_PREFIX=$data
& $tess --tessdata-dir $data --list-langs
if($LASTEXITCODE -ne 0){throw 'OCR language check failed'}
Write-Host 'OCR language check complete. Please restart the organizer.'
