@echo off
setlocal
set "WINGET=%LOCALAPPDATA%\Microsoft\WindowsApps\winget.exe"
if exist "%WINGET%" (
 "%WINGET%" install --id UB-Mannheim.TesseractOCR -e --source winget --accept-package-agreements --accept-source-agreements
) else (
 echo winget not found. Please install Tesseract OCR manually from:
 echo https://github.com/UB-Mannheim/tesseract/wiki
)
echo.
echo IMPORTANT: install both Russian [rus] and English [eng] language data.
echo If language data is missing, install rus.traineddata and eng.traineddata.
echo https://github.com/tesseract-ocr/tessdata_fast
pause
