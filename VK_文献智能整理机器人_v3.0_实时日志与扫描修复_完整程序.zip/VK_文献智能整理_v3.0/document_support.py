# -*- coding: utf-8 -*-
"""DJVU -> PDF conversion and limited document evidence extraction."""
import os
import re
import shutil
import subprocess
import zipfile
import tempfile
import locale
from pathlib import Path
from xml.etree import ElementTree


def find_ddjvu():
    djvutoy = Path(r'E:\DjVuToy-批量转换为pdf')
    # Only use an actual command-line converter binary, NOT DjVuToy.exe GUI.
    candidates = [os.environ.get('DDJVU_EXE', ''),
                  str(djvutoy / 'ddjvu.exe'),
                  str(djvutoy / 'bin' / 'ddjvu.exe'),
                  str(djvutoy / 'tools' / 'ddjvu.exe'),
                  shutil.which('ddjvu'),
                  r'C:\Program Files\DjVuZone\DjVuLibre\ddjvu.exe',
                  r'C:\Program Files (x86)\DjVuZone\DjVuLibre\ddjvu.exe',
                  r'C:\Program Files\DjVuLibre\ddjvu.exe',
                  r'C:\Program Files (x86)\DjVuLibre\ddjvu.exe',
                  r'C:\Program Files\DjVuLibre\bin\ddjvu.exe',
                  r'C:\Program Files (x86)\DjVuLibre\bin\ddjvu.exe',
                  r'C:\Program Files\DjVuLibre DjView\ddjvu.exe',
                  r'C:\Program Files (x86)\DjVuLibre DjView\ddjvu.exe',
                  str(Path.home() / 'AppData' / 'Local' / 'Programs' / 'DjVuLibre' / 'ddjvu.exe')]
    for root in (Path(os.environ.get('ProgramFiles', r'C:\Program Files')),
                 Path(os.environ.get('ProgramFiles(x86)', r'C:\Program Files (x86)'))):
        if root.is_dir():
            try:
                candidates.extend(str(x) for d in root.iterdir() if 'djvu' in d.name.lower() for x in d.rglob('ddjvu.exe'))
            except OSError: pass
    if djvutoy.is_dir():
        try:
            candidates.extend(str(x) for x in djvutoy.rglob('ddjvu.exe'))
        except OSError:
            pass
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return str(candidate)
    return None


def _run_converter(exe, src, dest, timeout):
    # Some Windows DjVuLibre builds use ANSI argv and cannot handle Chinese/Cyrillic paths.
    # The fallback below stages such paths in an ASCII-only temporary directory.
    command = [str(exe), '-format=pdf', str(src), str(dest)]
    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    return subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          timeout=timeout, cwd=str(Path(exe).parent), creationflags=flags)


def _explain_failure(result):
    data = ((result.stderr or b'') + b'\n' + (result.stdout or b''))[-1200:]
    for enc in ('utf-8', 'cp1251', 'cp936', locale.getpreferredencoding(False)):
        try: message = data.decode(enc); break
        except UnicodeError: continue
    else: message=data.decode('utf-8','replace')
    return '退出码 ' + str(result.returncode) + '；' + message.strip()[:800]


def convert_djvu(src, dest, timeout=3600):
    """Convert in the background with path compatibility fallback, validate PDF, preserve source."""
    exe = find_ddjvu()
    if not exe:
        raise RuntimeError('未找到 ddjvu.exe。DjView/DjVuToy 的图形程序不能代替命令行转换器；请运行 DiagnoseDJVU.bat。')
    src, dest = Path(src), Path(dest)
    if not src.is_file(): raise FileNotFoundError(src)
    if dest.exists(): raise FileExistsError(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    attempts=[]
    direct_ok = False
    try:
        result=_run_converter(exe, src, dest, timeout)
        if result.returncode == 0 and dest.is_file() and dest.stat().st_size > 100:
            direct_ok = True
            attempts.append('直接转换成功')
        else:
            attempts.append('直接转换：'+_explain_failure(result))
    except (OSError, subprocess.TimeoutExpired) as exc:
        attempts.append('直接转换异常：'+str(exc))
    if not direct_ok:
        if dest.exists(): dest.unlink()
        # Always try ASCII-only staging, including when Windows legacy binaries mishandle a path.
        with tempfile.TemporaryDirectory(prefix='vkdjvu_') as d:
            # Temp base directory may itself contain non-ASCII characters on some machines.
            stage = Path(d)
            input_copy = stage/'input.djvu'
            output_copy = stage/'output.pdf'
            try:
                import shutil
                shutil.copyfile(src, input_copy)
                result=_run_converter(exe, input_copy, output_copy, timeout)
                if result.returncode == 0 and output_copy.is_file() and output_copy.stat().st_size > 100:
                    shutil.copyfile(output_copy, dest)
                else:
                    attempts.append('英文临时路径转换：'+_explain_failure(result))
            except (OSError, subprocess.TimeoutExpired) as exc:
                attempts.append('英文临时路径转换异常：'+str(exc))
    if not dest.exists() or dest.stat().st_size <= 100:
        raise RuntimeError('DJVU转换失败；转换器 '+exe+'；'+'；'.join(attempts)[-1300:])
    try:
        import fitz
        with dest.open('rb') as f:
            if f.read(5) != b'%PDF-': raise ValueError('输出并非 PDF')
        with fitz.open(str(dest)) as doc:
            if len(doc)==0 or doc.is_encrypted: raise ValueError('PDF 页面无效或加密')
    except Exception as exc:
        dest.unlink(missing_ok=True)
        raise RuntimeError('DJVU已输出文件但PDF校验失败：'+str(exc)+'；'+'；'.join(attempts)[-400:])
    return dest

def extract_nonpdf_evidence(path, kind):
    """Best-effort evidence from selected non-PDF formats, no OCR claimed."""
    path = Path(path)
    try:
        if kind == '.txt':
            raw = path.read_bytes()[:45000]
            for enc in ('utf-8-sig', 'cp1251', 'utf-16'):
                try: return raw.decode(enc)[:12000], '', ''
                except UnicodeError: pass
        if kind == '.docx':
            with zipfile.ZipFile(path) as z:
                xml = z.read('word/document.xml')
                root = ElementTree.fromstring(xml)
                pieces = [x.text for x in root.iter() if x.tag.endswith('}t') and x.text]
                return ' '.join(pieces)[:12000], '', ''
        if kind == '.epub':
            with zipfile.ZipFile(path) as z:
                names = [x for x in z.namelist() if x.lower().endswith(('.opf','.xhtml','.html','.htm'))]
                pieces = []
                for name in names[:8]:
                    raw = z.read(name)[:45000].decode('utf-8', errors='replace')
                    text = re.sub(r'<[^>]*>', ' ', raw)
                    pieces.append(re.sub(r'\s+', ' ', text)[:2500])
                return '\n'.join(pieces)[:12000], '', ''
        if kind == '.fb2':
            data = path.read_bytes()[:100000]
            for enc in ('utf-8-sig', 'cp1251'):
                try:
                    raw = data.decode(enc)
                    txt = re.sub(r'<[^>]*>', ' ', raw)
                    return re.sub(r'\s+', ' ', txt)[:12000], '', ''
                except UnicodeDecodeError: pass
    except Exception as exc:
        return '', '', '无法读取正文：' + str(exc)[:120]
    return '', '', '该格式仅依据文件名翻译；如书名无意义，可手动编辑'
