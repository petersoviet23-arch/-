# -*- coding: utf-8 -*-
from document_support import find_ddjvu, convert_djvu
from pathlib import Path
import os, subprocess, sys
print('DJVU converter diagnosis')
print('DDJVU_EXE environment:',os.environ.get('DDJVU_EXE','(not set)'))
exe=find_ddjvu()
print('Detected ddjvu:',exe or 'NOT FOUND')
if not exe:
    print('Install DjVuLibre including command line tools; DjVuToy.exe alone is not enough.')
else:
    try:
        res=subprocess.run([exe,'-help'],cwd=str(Path(exe).parent),capture_output=True,timeout=15,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        print('ddjvu -help exit:',res.returncode)
        print((res.stdout+res.stderr)[-700:].decode('utf-8','replace'))
    except Exception as exc:
        print('Cannot launch ddjvu:',repr(exc))
if len(sys.argv)>1:
    src=Path(sys.argv[1])
    try:
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            output=Path(td)/'diagnostic.pdf'
            convert_djvu(src,output,timeout=240)
            print('ACTUAL CONVERSION SUCCESS; PDF bytes:',output.stat().st_size)
    except Exception as exc:
        print('ACTUAL CONVERSION FAILED:',repr(exc))
input('Press Enter to exit...')
