@echo off
cd /d "%~dp0"
python "DiagnoseDJVU.py" %*
if errorlevel 1 pause
