@echo off
setlocal
cd /d "%~dp0"
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" (echo PowerShell not found & pause & exit /b 1)
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0InstallAllDependencies.ps1"
echo.
pause
