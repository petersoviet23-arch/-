﻿$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
Set-Location -LiteralPath $PSScriptRoot
$log = Join-Path $PSScriptRoot 'install_dependencies.log'
$script:failed = New-Object 'System.Collections.Generic.List[string]'
function Log([string]$s) { ('[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$s) | Tee-Object -FilePath $log -Append | Out-Host }
function Fail([string]$s) { Log ('FAILED: '+$s); $script:failed.Add($s) }
function Find-Exe([string]$name) { $x=Get-Command $name -ErrorAction SilentlyContinue; if($x){ return $x.Source }; return $null }
'Installer started' | Set-Content -LiteralPath $log -Encoding UTF8
Log 'Step 1/4 - Check Python (Python 3.10+ supported)'
$py=Find-Exe 'python.exe'
if(-not $py){$py=Find-Exe 'python'}
if(-not $py){$py='C:\Users\35540\anaconda3\python.exe'; if(-not (Test-Path -LiteralPath $py)){$py=$null}}
# Do not pass Python code via -c. Windows PowerShell 5.1 may re-quote arguments.
# Run a temporary ASCII Python file to avoid quoting/encoding problems entirely.
$checkScript = Join-Path $env:TEMP 'vk_organizer_check_python.py'
$checkCode = @'
import sys
import importlib.util
print('Python executable:', sys.executable)
print('Python version:', sys.version.split()[0])
if sys.version_info < (3, 10):
    raise RuntimeError('Python 3.10 or newer is required')
if importlib.util.find_spec('fitz') is None:
    raise ImportError('PyMuPDF is not installed')
import fitz
print('PyMuPDF OK:', getattr(fitz, 'VersionBind', 'available'))
'@
[System.IO.File]::WriteAllText($checkScript, $checkCode, [System.Text.Encoding]::ASCII)
if(-not $py){
 Fail 'Python 3.10+ not found; install from python.org and rerun'
} else {
 Log ('Python: '+$py)
 try {
   # Install only if the import check fails. The import test itself is not a pip error.
   & $py $checkScript 2>&1 | ForEach-Object { Log ([string]$_) }
   $valid = ($LASTEXITCODE -eq 0)
   if(-not $valid){
      Log 'PyMuPDF import missing or broken. Trying pip installation/repair...'
      & $py -m pip --version 2>&1 | ForEach-Object {Log ([string]$_)}
      if($LASTEXITCODE -ne 0){& $py -m ensurepip --upgrade 2>&1 | ForEach-Object {Log ([string]$_)}}
      & $py -m pip install --disable-pip-version-check --retries 4 --timeout 40 --upgrade 'pymupdf>=1.23,<2' 2>&1 | ForEach-Object {Log ([string]$_)}
      if($LASTEXITCODE -ne 0){throw 'pip install failed (check internet or package repository)'}
      & $py $checkScript 2>&1 | ForEach-Object {Log ([string]$_)}
      if($LASTEXITCODE -ne 0){throw 'PyMuPDF import still failed after install'}
   }
   Log 'SUCCESS: Python and PyMuPDF verified'
 } catch {Fail ('Python dependency: '+$_)}
}
try{Remove-Item -LiteralPath $checkScript -Force -ErrorAction SilentlyContinue}catch{}
Log 'Step 2/4 - Install or locate Tesseract OCR'
$tess=@($env:TESSERACT_EXE, (Find-Exe 'tesseract.exe'), "$env:ProgramFiles\Tesseract-OCR\tesseract.exe", "${env:ProgramFiles(x86)}\Tesseract-OCR\tesseract.exe") | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) } | Select-Object -First 1
if(-not $tess){
 $winget=Find-Exe 'winget.exe'
 if(-not $winget){$candidate=Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps\winget.exe';if(Test-Path $candidate){$winget=$candidate}}
 if($winget){
   Log 'Installing Tesseract using winget; Windows may request administrator approval.'
   try{ & $winget install --id UB-Mannheim.TesseractOCR -e --source winget --accept-package-agreements --accept-source-agreements --disable-interactivity 2>&1 | ForEach-Object { "$($_)" | Add-Content -LiteralPath $log } } catch {Log ('winget error: '+$_)}
 }
 $tess=@((Find-Exe 'tesseract.exe'), "$env:ProgramFiles\Tesseract-OCR\tesseract.exe", "${env:ProgramFiles(x86)}\Tesseract-OCR\tesseract.exe") | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) } | Select-Object -First 1
}
if(-not $tess){Fail 'Tesseract OCR not found. Install UB-Mannheim Tesseract then rerun.'}
else {
 Log ('Tesseract: '+$tess)
 [Environment]::SetEnvironmentVariable('TESSERACT_EXE',$tess,'User');$env:TESSERACT_EXE=$tess
 Log 'Step 3/4 - Install Russian/English OCR language data to user profile'
 $parent=Join-Path $env:LOCALAPPDATA 'VKLibraryOrganizer\OCR';$data=Join-Path $parent 'tessdata';New-Item -ItemType Directory -Force -Path $data | Out-Null
 # Explicit --tessdata-dir ensures the language path is honored by all Tesseract builds.
 $env:TESSDATA_PREFIX=$data;[Environment]::SetEnvironmentVariable('TESSDATA_PREFIX',$data,'User')
 foreach($lang in @('rus','eng')){
   $dest=Join-Path $data ($lang+'.traineddata')
   if(-not(Test-Path $dest) -or (Get-Item $dest).Length -lt 100000){
    # Reuse any pre-installed language data before trying the internet.
    $native=Join-Path (Split-Path -Parent $tess) ('tessdata\'+$lang+'.traineddata')
    if(Test-Path -LiteralPath $native){Copy-Item -LiteralPath $native -Destination $dest -Force}
   }
   if(-not(Test-Path $dest) -or (Get-Item $dest).Length -lt 100000){
    try {
     $uri='https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/'+$lang+'.traineddata'
     $tmp=$dest+'.download'; Invoke-WebRequest -Uri $uri -OutFile $tmp -UseBasicParsing -TimeoutSec 180
     if((Get-Item $tmp).Length -lt 100000){throw 'File too small'}
     Move-Item -LiteralPath $tmp -Destination $dest -Force
    } catch {Remove-Item -LiteralPath ($dest+'.download') -ErrorAction SilentlyContinue;Fail ('OCR language '+$lang+': '+$_)}
   }
 }
 try {
   $langs=(& $tess --tessdata-dir $data --list-langs 2>&1 | Out-String)
   Log ('OCR tessdata directory: '+$data)
   Log $langs
   foreach($lang in @('rus','eng')){
     $expected=Join-Path $data ($lang+'.traineddata')
     if(-not (Test-Path -LiteralPath $expected)){
       Fail ('Tesseract language file missing: '+$expected)
     } elseif($langs -notmatch "(?m)^$lang\s*$"){
       Fail ('Tesseract could not load OCR language: '+$lang+'; check '+$expected)
     } else {Log ('SUCCESS: OCR language '+$lang)}
   }
 } catch {Fail ('Tesseract check: '+$_)}
}
Log 'Step 4/4 - Automatically install and validate DjVuLibre conversion engine'

# A viewer executable (DjVuToy.exe or djview.exe) is NOT a conversion CLI.
# The only accepted result is a working ddjvu.exe.
function Find-Ddjvu {
  $candidatePaths = @(
    $env:DDJVU_EXE,
    (Find-Exe 'ddjvu.exe'),
    'E:\DjVuToy-批量转换为pdf\ddjvu.exe',
    'E:\DjVuToy-批量转换为pdf\bin\ddjvu.exe',
    "$env:ProgramFiles\DjVuLibre\ddjvu.exe",
    "$env:ProgramFiles\DjVuLibre\bin\ddjvu.exe",
    "${env:ProgramFiles(x86)}\DjVuLibre\ddjvu.exe",
    "${env:ProgramFiles(x86)}\DjVuLibre\bin\ddjvu.exe",
    "$env:LOCALAPPDATA\Programs\DjVuLibre\ddjvu.exe",
    "$env:LOCALAPPDATA\Programs\DjVuLibre\bin\ddjvu.exe"
  )
  foreach($x in $candidatePaths){
    if($x -and (Test-Path -LiteralPath $x -PathType Leaf)){return (Resolve-Path -LiteralPath $x).Path}
  }
  $roots = @(
    'E:\DjVuToy-批量转换为pdf',
    "$env:ProgramFiles\DjVuLibre",
    "${env:ProgramFiles(x86)}\DjVuLibre",
    "$env:ProgramFiles\DjVuLibre DjView",
    "${env:ProgramFiles(x86)}\DjVuLibre DjView",
    "$env:LOCALAPPDATA\Programs\DjVuLibre",
    "$env:LOCALAPPDATA\Programs\DjVuLibre DjView"
  )
  foreach($root in $roots){
    if($root -and (Test-Path -LiteralPath $root -PathType Container)){
      $exe=Get-ChildItem -LiteralPath $root -Recurse -Filter 'ddjvu.exe' -File -ErrorAction SilentlyContinue | Select-Object -First 1
      if($exe){return $exe.FullName}
    }
  }
  return $null
}
function Verify-Ddjvu([string]$path){
  if(-not $path -or -not (Test-Path -LiteralPath $path -PathType Leaf)){return $false}
  try {
    $proc=Start-Process -FilePath $path -ArgumentList '-help' -PassThru -Wait -WindowStyle Hidden -RedirectStandardError (Join-Path $env:TEMP 'vk_ddjvu_stderr.txt') -RedirectStandardOutput (Join-Path $env:TEMP 'vk_ddjvu_stdout.txt') -ErrorAction Stop
    # ddjvu may return 0 or 1 when asked for help; executable must have actually launched.
    Log ('ddjvu.exe launched; help exit code: '+$proc.ExitCode)
    return $true
  } catch {
    Log ('ddjvu.exe cannot start: '+$_)
    return $false
  }
}
$djvu=Find-Ddjvu
if(-not (Verify-Ddjvu $djvu)){
  Log 'No working ddjvu.exe found. Installing official DjVuLibre DjView using winget...'
  $winget=Find-Exe 'winget.exe'
  if(-not $winget){
    $candidate=Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps\winget.exe'
    if(Test-Path -LiteralPath $candidate){$winget=$candidate}
  }
  if($winget){
    try{
      # Official Windows package ID; might trigger UAC depending on system permissions.
      & $winget install --id DjVuLibre.DjView --exact --source winget --silent --accept-package-agreements --accept-source-agreements --disable-interactivity 2>&1 | ForEach-Object {Log ([string]$_)}
      Log ('winget exit code: '+$LASTEXITCODE)
    } catch {Log ('winget installation error: '+$_)}
  } else {Log 'winget not detected. Trying official SourceForge Windows installer.'}
  $djvu=Find-Ddjvu
  if(-not (Verify-Ddjvu $djvu)){
    # Official project distribution, not a third-party mirror. Download and inspect the EXE header.
    $uri='https://sourceforge.net/projects/djvu/files/DjVuLibre_Windows/3.5.29%2B4.12/DjVuLibre-3.5.29_DjView-4.12_Setup.exe/download'
    $installer=Join-Path $env:TEMP 'VK_DjVuLibre_Setup.exe'
    try {
      Log ('Downloading official DjVuLibre Windows installer: '+$uri)
      Invoke-WebRequest -Uri $uri -OutFile $installer -UseBasicParsing -TimeoutSec 240 -MaximumRedirection 8
      $size=(Get-Item -LiteralPath $installer).Length
      if($size -lt 1000000){throw ('Downloaded file too small: '+$size)}
      $stream=[System.IO.File]::OpenRead($installer)
      try{$b1=$stream.ReadByte();$b2=$stream.ReadByte()}finally{$stream.Dispose()}
      if($b1 -ne 77 -or $b2 -ne 90){throw 'Downloaded file is not a Windows executable'}
      $sig=Get-AuthenticodeSignature -FilePath $installer
      Log ('Installer Authenticode signature status: '+$sig.Status)
      Log 'Launching official installer in silent mode; Windows may prompt for UAC approval.'
      $proc=Start-Process -FilePath $installer -ArgumentList '/S' -Wait -PassThru -ErrorAction Stop
      Log ('SourceForge installer exit code: '+$proc.ExitCode)
    } catch {Log ('SourceForge installation error: '+$_)}
    $djvu=Find-Ddjvu
  }
}
if(Verify-Ddjvu $djvu){
  $env:DDJVU_EXE=$djvu
  [Environment]::SetEnvironmentVariable('DDJVU_EXE',$djvu,'User')
  Log ('SUCCESS: Background DJVU converter installed and verified: '+$djvu)
} else {
  Fail 'DJVU converter was not verified. See installer log; install official DjVuLibre from https://sourceforge.net/projects/djvu/files/DjVuLibre_Windows/ and rerun.'
}
if($script:failed.Count -eq 0){Log 'SUCCESS - All required components detected. Run Start.bat.';exit 0}
Log ('PARTIAL - unresolved items: '+$script:failed.Count); foreach($item in $script:failed){Log ('  * '+$item)}
exit 1
