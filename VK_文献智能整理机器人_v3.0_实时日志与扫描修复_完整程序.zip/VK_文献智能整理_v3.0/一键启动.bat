@echo off
setlocal
cd /d "%~dp0"
set "PYEXE="
rem Prefer python.exe when available; py.exe may exist with no registered Python.
python -c "import sys; sys.exit(0 if sys.version_info.major == 3 else 1)" >nul 2>nul
if not errorlevel 1 set "PYEXE=python"
if not defined PYEXE (
    py -3 -c "import sys; sys.exit(0 if sys.version_info.major == 3 else 1)" >nul 2>nul
    if not errorlevel 1 set "PYEXE=py -3"
)
if not defined PYEXE (
    echo Python 3 not found. Test: python --version
    pause
    exit /b 1
)
%PYEXE% "VKLibraryOrganizer.py"
if errorlevel 1 (
    echo Operation failed. Check the error above.
    pause
    exit /b 1
)
