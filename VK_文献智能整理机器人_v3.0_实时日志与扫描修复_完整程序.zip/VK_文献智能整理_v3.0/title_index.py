# -*- coding: utf-8 -*-
"""Persistent title-first index for all formats. Do not infer content identity from a title."""
from pathlib import Path
import re
import sqlite3
import difflib
import unicodedata

def normalize_title(name):
    # Strip a few common scan/copy suffixes but preserve editions/volumes as distinct.
    value = unicodedata.normalize('NFKC', name or '').casefold()
    value = re.sub(r'\.(pdf|djvu|djv|epub|mobi|azw3|azw|fb2|docx?|txt)$', '', value)
    value = re.sub(r'(?:[_\s-]+(?:扫描(?:件|版)?|副本|复印件|copy|scan))+$', '', value, flags=re.I)
    return re.sub(r'[^\w\u4e00-\u9fff]+', '', value)

class TitleIndex:
    def __init__(self, dbpath):
        p=Path(dbpath)
        p.parent.mkdir(parents=True, exist_ok=True)
        self.db=sqlite3.connect(str(p))
        self.db.execute('CREATE TABLE IF NOT EXISTS titles (path TEXT PRIMARY KEY, title TEXT NOT NULL, norm TEXT NOT NULL, kind TEXT NOT NULL)')
        self.db.commit()
    def search(self,path,title):
        norm=normalize_title(title)
        if len(norm)<4: return []
        own=str(Path(path).resolve()).casefold()
        out=[]
        for ref,name,other,kind in self.db.execute('SELECT path,title,norm,kind FROM titles'):
            if ref.casefold()==own or len(other)<4: continue
            # Compare only same script; transliterated names must first be translated.
            sim=1.0 if norm==other else difflib.SequenceMatcher(None,norm,other).ratio()
            if sim>=.92 and Path(ref).is_file(): out.append((sim,ref,kind))
        return sorted(out,reverse=True)
    def add(self,path,title,kind):
        name=str(Path(path).resolve())
        self.db.execute('INSERT OR REPLACE INTO titles VALUES(?,?,?,?)',(name,title,normalize_title(title),kind))
        self.db.commit()
    def close(self): self.db.close()
