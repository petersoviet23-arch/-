@echo off
setlocal
cd /d "%~dp0"
python "patch_manager.py"
if errorlevel 1 pause
