# -*- coding: utf-8 -*-
"""DjVuToy GUI batch conversion bridge. No undocumented command-line conversion calls."""
import json
import hashlib
import os
import shutil
import subprocess
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from datetime import datetime

DJVUTOY = Path(r'E:\DjVuToy-批量转换为pdf\DjVuToy.exe')
DEFAULT = Path(r'C:\Users\35540\Downloads\VK_文献资料')
WORK = '_DjVuToy待转换'
BACKUP = '_DJVU原件'

def valid_pdf(p):
    import fitz
    if not p.is_file() or p.stat().st_size < 100:
        raise ValueError('PDF 不存在或文件太小')
    with p.open('rb') as f:
        if f.read(5) != b'%PDF-':
            raise ValueError('PDF 文件头错误')
    with fitz.open(str(p)) as doc:
        if doc.is_encrypted or len(doc) == 0:
            raise ValueError('PDF 加密或没有页面')
        return len(doc)

def unique(dest):
    if not dest.exists(): return dest
    i=2
    while True:
        cand=dest.with_name(f'{dest.stem} ({i}){dest.suffix}')
        if not cand.exists(): return cand
        i+=1

class Bridge:
    def __init__(self,root,dir_):
        self.root=root
        root.title('DjVuToy 批量转换桥接器｜V2.1')
        root.geometry('830x560')
        self.folder=tk.StringVar(value=str(dir_))
        self.exe=tk.StringVar(value=str(DJVUTOY))
        self.info=tk.StringVar(value='准备 DJVU → 使用 DjVuToy 转换整个待转换文件夹 → 检查并导入 PDF')
        f=ttk.Frame(root,padding=12);f.pack(fill='both',expand=True)
        row=ttk.Frame(f);row.pack(fill='x',pady=4)
        ttk.Label(row,text='原始文献目录').pack(side='left')
        ttk.Entry(row,textvariable=self.folder).pack(side='left',fill='x',expand=True,padx=8)
        ttk.Button(row,text='选择',command=self.choose).pack(side='left')
        row=ttk.Frame(f);row.pack(fill='x',pady=4)
        ttk.Label(row,text='DjVuToy.exe').pack(side='left')
        ttk.Entry(row,textvariable=self.exe).pack(side='left',fill='x',expand=True,padx=8)
        ttk.Button(row,text='选择',command=self.choose_exe).pack(side='left')
        buttons=ttk.Frame(f);buttons.pack(fill='x',pady=8)
        ttk.Button(buttons,text='① 准备批量转换',command=self.prepare).pack(side='left',padx=4)
        ttk.Button(buttons,text='② 启动 DjVuToy',command=self.launch).pack(side='left',padx=4)
        ttk.Button(buttons,text='打开待转换文件夹',command=self.open_work).pack(side='left',padx=4)
        ttk.Button(buttons,text='③ 检查并导入 PDF',command=self.import_pdfs).pack(side='left',padx=4)
        ttk.Label(f,text='操作说明：在 DjVuToy 中选择【转 PDF】→ 选择“_DjVuToy待转换”文件夹作为来源 → 开始批量转换。\n'+
                  '转换完成后返回本窗口按【③ 检查并导入 PDF】。只有验证通过的 PDF 才会导入主文献目录。',
                  justify='left',wraplength=790).pack(anchor='w',pady=9)
        ttk.Label(f,textvariable=self.info,foreground='#124b70',wraplength=770).pack(anchor='w',pady=8)
        self.log=tk.Text(f,height=18,wrap='word');self.log.pack(fill='both',expand=True)
        self.log.insert('end','原 DJVU 在导入成功前不会改动。已导入的原件转移至 _DJVU原件；不会删除文献。\n')
    def say(self,s):
        self.log.insert('end',s+'\n');self.log.see('end');self.root.update_idletasks()
    def choose(self):
        p=filedialog.askdirectory(initialdir=self.folder.get());
        if p:self.folder.set(p)
    def choose_exe(self):
        p=filedialog.askopenfilename(filetypes=[('Executable','*.exe')]);
        if p:self.exe.set(p)
    def getpaths(self):
        base=Path(self.folder.get());base.mkdir(parents=True,exist_ok=True)
        work=base/WORK;work.mkdir(exist_ok=True)
        return base,work,work/'conversion_manifest.json'
    def prepare(self):
        base,work,manifest=self.getpaths()
        if manifest.exists():
            old=json.loads(manifest.read_text(encoding='utf-8'))
        else:old=[]
        originals={r['source'] for r in old}
        paths=sorted([p for p in base.rglob('*') if p.is_file() and p.suffix.lower() in ('.djvu','.djv') and not any(x in p.parts for x in (WORK,BACKUP,'疑似重复文献'))])
        count=0
        for p in paths:
            if str(p) in originals:continue
            # Unique stage name prevents same-name files in different source subdirectories colliding.
            key=hashlib.sha256(str(p.resolve()).encode('utf-8')).hexdigest()[:10]
            staged=work/(p.stem+'__'+key+p.suffix.lower())
            if staged.exists():
                self.say('待转换区已存在 '+staged.name+'，未覆盖');continue
            shutil.copy2(p,staged)
            old.append({'source':str(p),'staged':str(staged),'size':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns,'imported':False})
            count+=1
        manifest.write_text(json.dumps(old,ensure_ascii=False,indent=2),encoding='utf-8')
        self.info.set(f'新准备 {count} 个文件；待转换区：{work}')
        self.say(f'已准备 {count} 个 DJVU 文件，选择此文件夹在 DjVuToy 中批量转 PDF：{work}')
    def launch(self):
        exe=Path(self.exe.get())
        if not exe.is_file():
            messagebox.showerror('未找到 DjVuToy',f'找不到：{exe}\n请检查 E: 盘或点击【选择】指定 exe。');return
        subprocess.Popen([str(exe)],cwd=str(exe.parent))
        self.say('已启动 DjVuToy 图形界面。请手动选择【转 PDF】与待转换目录；不假定 GUI 支持命令行参数。')
    def open_work(self):
        _,work,_=self.getpaths()
        if os.name=='nt':os.startfile(str(work))
        else:self.say(str(work))
    def import_pdfs(self):
        base,work,manifest=self.getpaths()
        if not manifest.is_file():
            messagebox.showinfo('无待处理任务','请先点击【① 准备批量转换】');return
        records=json.loads(manifest.read_text(encoding='utf-8'))
        imported=0;pending=0;problems=[]
        for r in records:
            if r.get('imported'):continue
            src=Path(r['source']); staged=Path(r['staged']);pdf=staged.with_suffix('.pdf')
            if not pdf.exists():pending+=1;continue
            try:
                pages=valid_pdf(pdf)
                if not src.exists():raise FileNotFoundError('源 DJVU 已不存在：'+str(src))
                if src.stat().st_size != r['size'] or src.stat().st_mtime_ns!=r['mtime_ns']:
                    raise RuntimeError('源 DJVU 自准备后被修改，请人工检查')
                # Avoid an intermediate PDF with the same name as a source PDF or other imported output.
                dest=unique(src.with_suffix('.pdf'))
                tmp=dest.with_suffix('.importing.pdf')
                if tmp.exists():raise FileExistsError('存在未完成导入临时文件：'+str(tmp))
                try:
                    shutil.copy2(pdf,tmp);valid_pdf(tmp)
                    tmp.rename(dest)
                finally:
                    if tmp.exists():tmp.unlink()
                backup=base/BACKUP;backup.mkdir(parents=True,exist_ok=True)
                backpath=unique(backup/src.name)
                try:
                    shutil.move(str(src),str(backpath))
                except Exception as e:
                    # Keep validated PDF and original; report partial completion.
                    raise RuntimeError('PDF 已导入但 DJVU 原件备份未完成：'+str(e))
                r['imported']=True;r['pdf']=str(dest);r['backup']=str(backpath)
                manifest.write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
                imported+=1
                self.say(f'成功：{src.name} → {dest.name} ({pages}页)；原 DJVU 已备份')
            except Exception as e:
                problems.append(f'{staged.name}: {e}');self.say('需处理：'+problems[-1])
        self.info.set(f'本轮导入 {imported} 个 PDF；尚未转换 {pending} 个；异常 {len(problems)} 个。')
        self.say('导入完成。返回主程序点击【扫描文件 + 生成中文候选书名】继续翻译及前十页查重。')
        if problems:messagebox.showwarning('有文件未成功导入','\n'.join(problems[:8]))

if __name__=='__main__':
    root=tk.Tk()
    Bridge(root,Path(sys.argv[1]) if len(sys.argv)>1 else DEFAULT)
    root.mainloop()
