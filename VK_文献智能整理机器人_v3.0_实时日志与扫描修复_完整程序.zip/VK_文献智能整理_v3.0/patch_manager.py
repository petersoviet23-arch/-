# -*- coding: utf-8 -*-
"""Safe offline patch manager for VKLibraryOrganizer. Python 3.10+ stdlib only."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
import zipfile

MAX_FILES = 40
MAX_FILE = 12 * 1024 * 1024
MAX_TOTAL = 48 * 1024 * 1024
ALLOWED = {'VKLibraryOrganizer.py', 'patch_manager.py', 'document_support.py', 'duplicate_detector.py', 'title_index.py', 'DjVuToyBridge.py', 'DiagnoseDJVU.py'}

def valid_name(name):
    return name in ALLOWED and '/' not in name and '\\' not in name and '..' not in name

def inspect_patch(archive, target):
    archive = Path(archive)
    target = Path(target)
    if not archive.is_file():
        raise ValueError('补丁文件不存在')
    if not target.joinpath('VKLibraryOrganizer.py').is_file():
        raise ValueError('目标目录内找不到 VKLibraryOrganizer.py')
    with zipfile.ZipFile(archive) as z:
        entries = z.infolist()
        if len(entries) > MAX_FILES + 1:
            raise ValueError('补丁内文件过多')
        if len({e.filename for e in entries}) != len(entries):
            raise ValueError('补丁存在重复文件路径')
        manifest = json.loads(z.read('manifest.json').decode('utf-8'))
        if manifest.get('product') != 'VKLibraryOrganizer' or not isinstance(manifest.get('files'), dict):
            raise ValueError('不是受支持的补丁格式')
        version = manifest.get('version')
        if not isinstance(version,str) or len(version)>50 or not version:
            raise ValueError('补丁版本号无效')
        files = manifest['files']
        if not files or len(files)>MAX_FILES:
            raise ValueError('补丁没有可更新的程序文件')
        if set(x.filename for x in entries) != set(files)|{'manifest.json'}:
            raise ValueError('补丁包含未声明的文件')
        total = 0
        for name, expected in files.items():
            if not valid_name(name):
                raise ValueError('不允许更新该文件：' + name)
            zinfo = z.getinfo(name)
            if zinfo.is_dir() or zinfo.file_size>MAX_FILE or zinfo.file_size<0:
                raise ValueError('文件尺寸异常：' + name)
            # Reject symlinks on Unix-created ZIP archives.
            if (zinfo.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError('补丁中不允许符号链接')
            total += zinfo.file_size
            if total>MAX_TOTAL:
                raise ValueError('补丁体积超限')
            if not isinstance(expected,str) or len(expected)!=64 or any(c not in '0123456789abcdef' for c in expected):
                raise ValueError('哈希格式错误：' + name)
            if hashlib.sha256(z.read(name)).hexdigest()!=expected:
                raise ValueError('校验失败：' + name)
    return {'version':version, 'files':files}

def apply_patch(archive,target):
    archive=Path(archive).resolve()
    target=Path(target).resolve()
    info=inspect_patch(archive,target)
    backup_base=target/'_程序补丁备份'
    backup_base.mkdir(parents=True,exist_ok=True)
    stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    backup=backup_base/stamp
    backup.mkdir()
    replaced=[]
    created=[]
    try:
        with zipfile.ZipFile(archive) as z:
            for name in info['files']:
                dest=target/name
                if dest.exists():
                    shutil.copy2(dest,backup/name)
                else:
                    created.append(dest)
                temp=target/(name+'.patchtmp')
                try:
                    with temp.open('wb') as out:
                        out.write(z.read(name))
                    # Preserve target's write access / avoid partial write.
                    os.replace(temp,dest)
                finally:
                    temp.unlink(missing_ok=True)
                replaced.append(dest)
        (backup/'补丁安装记录.json').write_text(json.dumps({'version':info['version'],'files':list(info['files']),'installed_at':datetime.datetime.now().isoformat()},ensure_ascii=False,indent=2),encoding='utf-8')
    except Exception:
        for path in reversed(replaced):
            old=backup/path.name
            if old.exists():
                shutil.copy2(old,path)
            elif path in created:
                path.unlink(missing_ok=True)
        raise
    return backup

def rollback(target, backup):
    target=Path(target).resolve(); backup=Path(backup).resolve()
    if backup.parent != (target/'_程序补丁备份').resolve():
        raise ValueError('备份目录不在程序专用备份文件夹内')
    record=json.loads((backup/'补丁安装记录.json').read_text(encoding='utf-8'))
    for name in record['files']:
        if not valid_name(name): raise ValueError('备份含非法文件路径')
    for name in record['files']:
        saved=backup/name
        if saved.exists(): shutil.copy2(saved,target/name)
        else: (target/name).unlink(missing_ok=True)
    return record

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--apply');ap.add_argument('--target');ap.add_argument('--wait-pid',type=int,default=0)
    ap.add_argument('--rollback')
    args=ap.parse_args()
    if not args.target:
        target=Path(__file__).resolve().parent
    else: target=Path(args.target).resolve()
    try:
        if args.apply:
            if args.wait_pid:
                # Windows: OpenProcess wait handle would be ideal; wait conservatively
                # until the original process exits, with a fixed timeout.
                for _ in range(120):
                    try:
                        import ctypes
                        PROCESS_QUERY_LIMITED_INFORMATION=0x1000
                        h=ctypes.windll.kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,False,args.wait_pid)
                        if not h: break
                        ctypes.windll.kernel32.CloseHandle(h)
                    except Exception:
                        break
                    time.sleep(.5)
                else:
                    raise RuntimeError('主程序未关闭，请先退出再安装')
            saved=apply_patch(args.apply,target)
            print('SUCCESS: 补丁安装完成。备份：',saved)
        elif args.rollback:
            result=rollback(target,args.rollback)
            print('SUCCESS: 已恢复旧代码：',result['version'])
        else:
            import tkinter as tk
            from tkinter import filedialog,messagebox
            root=tk.Tk();root.withdraw()
            p=filedialog.askopenfilename(title='选择补丁 ZIP',filetypes=[('ZIP补丁','*.zip')])
            if p:
                info=inspect_patch(p,target)
                if messagebox.askyesno('安装补丁', '版本：'+info['version']+'\\n安装时必须关闭文献机器人。\\n是否继续？'):
                    saved=apply_patch(p,target)
                    messagebox.showinfo('成功','补丁已安装，备份：'+str(saved))
            root.destroy()
    except Exception as exc:
        print('FAILED:',exc,file=sys.stderr)
        if not args.apply and not args.rollback:
            try:
                from tkinter import messagebox
                messagebox.showerror('补丁失败',str(exc))
            except Exception: pass
        sys.exit(1)

if __name__=='__main__': main()
