﻿$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
Set-Location -LiteralPath $PSScriptRoot
$log = Join-Path $PSScriptRoot 'install_dependencies.log'
$script:failed = New-Object 'System.Collections.Generic.List[string]'
function Log([string]$s) { ('[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$s) | Tee-Object -FilePath $log -Append | Out-Host }
function Fail([string]$s) { Log ('FAILED: '+$s); $script:failed.Add($s) }
function Find-Exe([string]$name) { $x=Get-Command $name -ErrorAction SilentlyContinue; if($x){ return $x.Source }; return $null }
'Installer started' | Set-Content -LiteralPath $log -Encoding UTF8
Log 'Step 1/3 - Check Python (Python 3.10+ supported)'
$py=Find-Exe 'python.exe'
if(-not $py){$py=Find-Exe 'python'}
if(-not $py){$py='C:\Users\35540\anaconda3\python.exe'; if(-not (Test-Path -LiteralPath $py)){$py=$null}}
# Do not pass Python code via -c. Windows PowerShell 5.1 may re-quote arguments.
# Run a temporary ASCII Python file to avoid quoting/encoding problems entirely.
$checkScript = Join-Path $env:TEMP 'vk_organizer_check_python.py'
$checkCode = @'
import sys
import importlib.util
print('Python executable:', sys.executable)
print('Python version:', sys.version.split()[0])
if sys.version_info < (3, 10):
    raise RuntimeError('Python 3.10 or newer is required')
if importlib.util.find_spec('fitz') is None:
    raise ImportError('PyMuPDF is not installed')
import fitz
print('PyMuPDF OK:', getattr(fitz, 'VersionBind', 'available'))
'@
[System.IO.File]::WriteAllText($checkScript, $checkCode, [System.Text.Encoding]::ASCII)
if(-not $py){
 Fail 'Python 3.10+ not found; install from python.org and rerun'
} else {
 Log ('Python: '+$py)
 try {
   # Install only if the import check fails. The import test itself is not a pip error.
   & $py $checkScript 2>&1 | ForEach-Object { Log ([string]$_) }
   $valid = ($LASTEXITCODE -eq 0)
   if(-not $valid){
      Log 'PyMuPDF import missing or broken. Trying pip installation/repair...'
      & $py -m pip --version 2>&1 | ForEach-Object {Log ([string]$_)}
      if($LASTEXITCODE -ne 0){& $py -m ensurepip --upgrade 2>&1 | ForEach-Object {Log ([string]$_)}}
      & $py -m pip install --disable-pip-version-check --retries 4 --timeout 40 --upgrade 'pymupdf>=1.23,<2' 2>&1 | ForEach-Object {Log ([string]$_)}
      if($LASTEXITCODE -ne 0){throw 'pip install failed (check internet or package repository)'}
      & $py $checkScript 2>&1 | ForEach-Object {Log ([string]$_)}
      if($LASTEXITCODE -ne 0){throw 'PyMuPDF import still failed after install'}
   }
   Log 'SUCCESS: Python and PyMuPDF verified'
 } catch {Fail ('Python dependency: '+$_)}
}
try{Remove-Item -LiteralPath $checkScript -Force -ErrorAction SilentlyContinue}catch{}
Log 'Step 2/3 - Install or locate Tesseract OCR'
$tess=@($env:TESSERACT_EXE, (Find-Exe 'tesseract.exe'), "$env:ProgramFiles\Tesseract-OCR\tesseract.exe", "${env:ProgramFiles(x86)}\Tesseract-OCR\tesseract.exe") | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) } | Select-Object -First 1
if(-not $tess){
 $winget=Find-Exe 'winget.exe'
 if(-not $winget){$candidate=Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps\winget.exe';if(Test-Path $candidate){$winget=$candidate}}
 if($winget){
   Log 'Installing Tesseract using winget; Windows may request administrator approval.'
   try{ & $winget install --id UB-Mannheim.TesseractOCR -e --source winget --accept-package-agreements --accept-source-agreements --disable-interactivity 2>&1 | ForEach-Object { "$($_)" | Add-Content -LiteralPath $log } } catch {Log ('winget error: '+$_)}
 }
 $tess=@((Find-Exe 'tesseract.exe'), "$env:ProgramFiles\Tesseract-OCR\tesseract.exe", "${env:ProgramFiles(x86)}\Tesseract-OCR\tesseract.exe") | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) } | Select-Object -First 1
}
if(-not $tess){Fail 'Tesseract OCR not found. Install UB-Mannheim Tesseract then rerun.'}
else {
 Log ('Tesseract: '+$tess)
 [Environment]::SetEnvironmentVariable('TESSERACT_EXE',$tess,'User');$env:TESSERACT_EXE=$tess
 Log 'Step 3/3 - Install Russian/English OCR language data to user profile'
 $parent=Join-Path $env:LOCALAPPDATA 'VKLibraryOrganizer\OCR';$data=Join-Path $parent 'tessdata';New-Item -ItemType Directory -Force -Path $data | Out-Null
 # Explicit --tessdata-dir ensures the language path is honored by all Tesseract builds.
 $env:TESSDATA_PREFIX=$data;[Environment]::SetEnvironmentVariable('TESSDATA_PREFIX',$data,'User')
 foreach($lang in @('rus','eng')){
   $dest=Join-Path $data ($lang+'.traineddata')
   if(-not(Test-Path $dest) -or (Get-Item $dest).Length -lt 100000){
    # Reuse any pre-installed language data before trying the internet.
    $native=Join-Path (Split-Path -Parent $tess) ('tessdata\'+$lang+'.traineddata')
    if(Test-Path -LiteralPath $native){Copy-Item -LiteralPath $native -Destination $dest -Force}
   }
   if(-not(Test-Path $dest) -or (Get-Item $dest).Length -lt 100000){
    try {
     $uri='https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/'+$lang+'.traineddata'
     $tmp=$dest+'.download'; Invoke-WebRequest -Uri $uri -OutFile $tmp -UseBasicParsing -TimeoutSec 180
     if((Get-Item $tmp).Length -lt 100000){throw 'File too small'}
     Move-Item -LiteralPath $tmp -Destination $dest -Force
    } catch {Remove-Item -LiteralPath ($dest+'.download') -ErrorAction SilentlyContinue;Fail ('OCR language '+$lang+': '+$_)}
   }
 }
 try {
   $langs=(& $tess --tessdata-dir $data --list-langs 2>&1 | Out-String)
   Log ('OCR tessdata directory: '+$data)
   Log $langs
   foreach($lang in @('rus','eng')){
     $expected=Join-Path $data ($lang+'.traineddata')
     if(-not (Test-Path -LiteralPath $expected)){
       Fail ('Tesseract language file missing: '+$expected)
     } elseif($langs -notmatch "(?m)^$lang\s*$"){
       Fail ('Tesseract could not load OCR language: '+$lang+'; check '+$expected)
     } else {Log ('SUCCESS: OCR language '+$lang)}
   }
 } catch {Fail ('Tesseract check: '+$_)}
}

Log 'DJVU name translation only: no DjVuLibre converter installation required.'
if($script:failed.Count -eq 0){Log 'SUCCESS - All required components detected. Run Start.bat.';exit 0}
Log ('PARTIAL - unresolved items: '+$script:failed.Count); foreach($item in $script:failed){Log ('  * '+$item)}
exit 1
