# -*- coding: utf-8 -*-
"""Rename ONLY subdirectory names of the user-selected root.

Never open, edit, translate, rename, convert, or delete any file within those directories.
Directory paths in organizer checkpoints/indexes are synchronized after the rename.
"""
import json
import random
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
from pathlib import Path
import queue
import re
import sqlite3
import threading
import urllib.request
import urllib.error
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog

SKIP_NAMES = {'_整理日志', '_OCR缓存', '_DJVU原件', '_DjVuToy待转换', '疑似重复文献', '_程序补丁备份'}
ILLEGAL = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
HANZI = re.compile(r'[\u4e00-\u9fff]')
CYRILLIC = re.compile(r'[\u0400-\u052f]')
LONG_LATIN_WORD = re.compile(r'(?<![A-Za-z])[A-Za-z]{2,}(?![A-Za-z])')

def needs_folder_translation(name):
    return (not HANZI.search(name)) or bool(CYRILLIC.search(name) or any(not re.fullmatch(r'[IVXLCDM]+', word, flags=re.I) for word in LONG_LATIN_WORD.findall(name)))


def safe_name(value):
    value = ILLEGAL.sub(' ', value or '').strip().strip(' .')
    value = re.sub(r'\s+', ' ', value)
    if value.upper() in {'CON','PRN','AUX','NUL'} or re.fullmatch(r'(COM|LPT)[1-9]', value.upper()):
        return ''
    return value[:120].rstrip(' .')


def is_descendant_directory(path, base):
    """Require a real, non-symlink directory strictly BELOW selected root."""
    base = Path(base).resolve()
    path = Path(path)
    if path.is_symlink() or not path.is_dir():
        return False
    actual = path.resolve()
    return actual != base and base in actual.parents


def folder_candidates(base, recursive=True):
    base = Path(base).resolve()
    if not base.is_dir():
        return []
    items=[]
    for current, dirs, files in os.walk(base, followlinks=False):
        dirs[:] = [d for d in dirs if d not in SKIP_NAMES and not (Path(current)/d).is_symlink()]
        if not recursive and Path(current) != base:
            dirs[:] = []
            continue
        for d in dirs:
            p=Path(current)/d
            if needs_folder_translation(d) and is_descendant_directory(p, base):
                items.append(p)
        if not recursive:
            break
    return sorted(items, key=lambda p:(-len(p.parts), str(p).casefold()))


def parse_folder_translation(content):
    """Accept plain titles, fenced JSON, or short multiline answers; never invent from nothing."""
    if isinstance(content, list):
        content = '\n'.join(str(part.get('text', '')) if isinstance(part, dict) else str(part) for part in content)
    if content is None:
        return ''
    raw=str(content).strip().lstrip('\ufeff')
    raw=re.sub(r'^```(?:json|text|markdown)?\s*|\s*```$', '', raw, flags=re.I).strip()
    if raw.startswith('{'):
        try:
            obj=json.loads(raw)
            for key in ('title_zh','folder_name_zh','name_zh','translated_name','translation','title','name'):
                if isinstance(obj.get(key), str) and HANZI.search(obj[key]):
                    raw=obj[key];break
        except (ValueError, TypeError):
            pass
    raw=re.sub(r'(?i)^\s*(?:翻译(?:结果|名称)?|中文(?:名称|译名|书名)?|建议(?:译名|名称)?|translated name|translation)\s*[：:]\s*','',raw)
    raw=raw.strip(' \t\r\n"\'“”‘’《》')
    if '\n' in raw:
        lines=[re.sub(r'^\s*(?:[-*•]|\d+[.)、])\s*','',x).strip() for x in raw.splitlines()]
        # Prefer actual Chinese candidate, not explanatory text
        candidates=[x for x in lines if HANZI.search(x) and not re.match(r'^\s*(?:注|说明|理由|解释|注意)[：:]?',x) and not re.fullmatch(r'\s*(?:中文名|中文名称|译名|翻译结果)[：:]?\s*',x)]
        raw=min(candidates,key=len) if candidates else ''
    raw=re.sub(r'^\s*[《"“](.*?)[》"”]\s*$',r'\1',raw)
    result=safe_name(raw)
    if not HANZI.search(result) or len(result)<2 or CYRILLIC.search(result) or any(not re.fullmatch(r'[IVXLCDM]+', word, flags=re.I) for word in LONG_LATIN_WORD.findall(result)):
        return ''
    if result in {'无法翻译','无法确定','未知','空字符串','无','无法判断','未获得有效中文名称'}:
        return ''
    return result


def translate_folder(api_key, model, name):
    """Accurate folder-name translation; retries only transient failures or malformed answers."""
    if not api_key.strip():
        return '', '未填写 DeepSeek API Key'
    model=(model or '').strip() or 'deepseek-flash'
    system=('你是俄语与英语文献目录命名翻译助手。请把给定的文件夹名称翻译成简体中文，'
            '包括混在中文名称中的俄文、英文、拉丁转写的作者姓名和书名。保留已有正确的中文和年份，必须只输出一个中文文件夹名称，'
            '不要解释、不要 JSON、不要引号或路径；保留年份、卷号、作者等可确认信息。'
            '仅当输入完全无法辨认时，回复“无法辨认”。不要把俄文直接抄回。')
    prompts=[name,
             f'请将以下文件夹名称翻译为简体中文。必须有中文汉字，保留明确的年份、作者；只给中文名称：\n{name}',
             f'这是俄语/英语的书籍或资料文件夹名，请使用通行中文译名，无法确认的专名可以音译。只输出一行中文名称：\n{name}']
    last_error=''
    for stage, prompt in enumerate(prompts):
        data={'model':model,'messages':[{'role':'system','content':system},
              {'role':'user','content':prompt}], 'temperature':0,'max_tokens':360}
        req=urllib.request.Request('https://api.deepseek.com/chat/completions',
            data=json.dumps(data,ensure_ascii=False).encode('utf-8'),
            headers={'Authorization':'Bearer '+api_key.strip(),'Content-Type':'application/json','Accept':'application/json'},method='POST')
        try:
            with urllib.request.urlopen(req,timeout=40) as res:
                response=json.load(res)
            choice=(response.get('choices') or [{}])[0]
            msg=choice.get('message') or {}
            value=parse_folder_translation(msg.get('content'))
            if value:
                return value, ''
            last_error=f'模型未返回中文候选（第{stage+1}轮；finish_reason={choice.get("finish_reason", "unknown")}）'
        except urllib.error.HTTPError as exc:
            try:
                detail=exc.read(400).decode('utf-8',errors='replace')
                obj=json.loads(detail)
                detail=str((obj.get('error') or {}).get('message') or detail)
            except Exception:
                detail=''
            last_error=f'HTTP {exc.code}：{detail[:100]}'
            if exc.code in (400,401,402,403,404):
                return '',last_error
            if exc.code in (429,500,502,503,504):
                time.sleep(min(6,2+stage*2+random.random()))
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            last_error=f'网络错误：{type(exc).__name__}：{str(exc)[:90]}'
            if stage<2:time.sleep(1+stage)
        except (ValueError,KeyError,IndexError,TypeError) as exc:
            last_error=f'API响应解析异常：{type(exc).__name__}：{str(exc)[:90]}'
    return '',last_error or '未获得有效中文名称'


def rebased_path(value, old, new):
    """Replace only exact path components, not coincidental string prefixes."""
    if not isinstance(value,str) or not value:
        return value
    a=os.path.normcase(os.path.normpath(value))
    b=os.path.normcase(os.path.normpath(str(old)))
    if a==b:
        return str(new)
    if a.startswith(b+os.sep):
        return str(new)+value[len(str(old)):]
    return value


def update_sqlite_paths(base, old, new, reporter):
    for dbname, table in [('前十页历史指纹.sqlite','books'), ('书名历史索引.sqlite','titles')]:
        file=base/'_整理日志'/dbname
        if not file.exists():
            continue
        try:
            with sqlite3.connect(str(file),timeout=8) as db:
                found=db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone()
                if not found: continue
                rows=db.execute(f'SELECT path FROM {table}').fetchall()
                for (src,) in rows:
                    dest=rebased_path(src,old,new)
                    if src!=dest:
                        db.execute(f'UPDATE OR REPLACE {table} SET path=? WHERE path=?',(dest,src))
        except Exception as exc:
            reporter(f'索引路径同步失败 {dbname}: {exc}', 'WARNING')


class FolderManager:
    def __init__(self, app):
        self.app=app
        self.root=app.root
        self.base=Path(app.folder.get()).resolve()
        self.win=tk.Toplevel(self.root)
        self.win.title('仅翻译所选目录下的子文件夹名称｜不修改内部文件')
        self.win.geometry('1050x570')
        self.rows={}
        self.order=[]
        self.msg=queue.Queue()
        self.translating=False
        self.translation_total=0
        self.translation_done=0
        self.recursive=tk.BooleanVar(value=True)
        self.status=tk.StringVar(value='仅处理所选根目录下的子文件夹名称；根目录与所有内部文件均不修改。')
        top=ttk.Frame(self.win,padding=8);top.pack(fill='x')
        ttk.Checkbutton(top,text='包含下级及更深层子文件夹',variable=self.recursive).pack(side='left',padx=6)
        ttk.Button(top,text='扫描子文件夹名称',command=self.scan).pack(side='left',padx=6)
        ttk.Button(top,text='批量翻译文件夹名',command=self.translate).pack(side='left',padx=6)
        ttk.Button(top,text='重试失败/未翻译',command=self.retry_failed).pack(side='left',padx=6)
        ttk.Button(top,text='编辑选中译名',command=self.edit).pack(side='left',padx=6)
        ttk.Button(top,text='一键勾选全部有效译名',command=self.select_all).pack(side='left',padx=6)
        ttk.Button(top,text='仅修改勾选的文件夹名称',command=self.apply).pack(side='left',padx=6)
        frame=ttk.Frame(self.win,padding=8);frame.pack(fill='both',expand=True)
        self.tree=ttk.Treeview(frame,columns=('mark','original','new','result'),show='headings',selectmode='browse')
        for k,label,width in [('mark','勾选',55),('original','原文件夹完整路径',420),('new','建议中文名称',260),('result','状态',210)]:
            self.tree.heading(k,text=label);self.tree.column(k,width=width,stretch=k!='mark')
        sc=ttk.Scrollbar(frame,orient='vertical',command=self.tree.yview)
        self.tree.configure(yscrollcommand=sc.set)
        self.tree.pack(side='left',fill='both',expand=True);sc.pack(side='right',fill='y')
        self.tree.bind('<Double-1>',self.double_click)
        ttk.Label(self.win,text='安全范围：仅重命名根目录下的文件夹本身；不会修改或重命名其中的 PDF、DJVU、EPUB 等任何文件。',padding=(8,2)).pack(fill='x')
        ttk.Label(self.win,textvariable=self.status,padding=8).pack(fill='x')
        self.scan()
        self.win.after(150,self.poll)

    def _busy(self):
        return self.app.busy or self.app.rename_running or self.app.djvu_running

    def scan(self):
        if self.translating: return
        self.rows.clear();self.order.clear()
        for i,path in enumerate(folder_candidates(self.base,self.recursive.get())):
            k=str(i)
            self.rows[k]={'path':path,'new':'','checked':False,'state':'等待翻译'}
            self.order.append(k)
        self.render_all()
        self.status.set(f'根目录：{self.base}；发现 {len(self.rows)} 个外语子文件夹。已跳过中文目录，未扫描文件内容。')

    def render_all(self):
        for iid in self.tree.get_children():self.tree.delete(iid)
        for k in self.order:
            d=self.rows[k]
            self.tree.insert('', 'end',iid=k,values=('☑' if d['checked'] else '□',str(d['path']),d['new'],d['state']))

    def refresh(self,k):
        if not self.tree.exists(k):return
        d=self.rows[k]
        self.tree.item(k,values=('☑' if d['checked'] else '□',str(d['path']),d['new'],d['state']))

    def retry_failed(self):
        self.translate(retry_failed=True)

    def translate(self, retry_failed=False):
        if self.translating or self._busy():
            messagebox.showwarning('操作冲突','请先结束扫描和改名任务。',parent=self.win)
            return
        key=self.app.key.get().strip()
        if not key:
            messagebox.showwarning('API Key','请先在主界面填写 DeepSeek API Key。',parent=self.win)
            return
        jobs=[(k,self.rows[k]['path'].name) for k in self.order
              if not self.rows[k]['new'] and self.rows[k]['path'].is_dir()]
        if not jobs:
            self.status.set('所有记录已有候选译名，或目录已不存在。')
            return
        self.translating=True
        self.translation_done=0
        self.translation_total=len(jobs)
        model=self.app.model.get()
        self.app.write_log(f'子文件夹翻译启动：{len(jobs)} 个，模型={model}，工作线程=4')
        def worker():
            try:
                with ThreadPoolExecutor(max_workers=min(4,len(jobs))) as executor:
                    futures={executor.submit(translate_folder,key,model,name):(k,name) for k,name in jobs}
                    for future in as_completed(futures):
                        k,name=futures[future]
                        try:
                            title,error=future.result()
                        except Exception as exc:
                            title,error='',f'{type(exc).__name__}: {str(exc)[:120]}'
                        self.msg.put(('translated',k,title,error))
            finally:
                self.msg.put(('finish',))
        threading.Thread(target=worker,daemon=True).start()
        self.status.set(f'翻译中：0/{len(jobs)}；最多4项同时进行')

    def poll(self):
        if not self.win.winfo_exists():return
        processed=0
        while processed<50:
            try: item=self.msg.get_nowait()
            except queue.Empty:break
            processed+=1
            if item[0]=='translated':
                _,k,title,error=item
                if k in self.rows:
                    d=self.rows[k];d['new']=title;d['checked']=bool(title and not needs_folder_translation(title));d['state']=error or '已生成中文候选，等待确认'
                    self.translation_done+=1
                    self.status.set(f'翻译进度：{self.translation_done}/{self.translation_total}；成功/失败可在状态列查看')
                    if error:self.app.write_log(f'子文件夹翻译未完成：{d["path"].name}：{error}','WARNING')
                    self.refresh(k)
            elif item[0]=='finish':
                self.translating=False
                self.status.set('翻译结束。请核对建议名称并选择要重命名的文件夹。')
        self.win.after(150,self.poll)

    def double_click(self,event):
        k=self.tree.identify_row(event.y)
        col=self.tree.identify_column(event.x)
        if not k:return
        if col=='#1':
            self.rows[k]['checked']=not self.rows[k]['checked'];self.refresh(k)
        elif col=='#3':self.edit(k)

    def edit(self,k=None):
        if k is None:
            selected=self.tree.selection()
            if not selected:return
            k=selected[0]
        d=self.rows[k]
        result=simpledialog.askstring('编辑中文文件夹名称','目标文件夹名称（不要输入路径）：',initialvalue=d['new'],parent=self.win)
        if result is None:return
        title=safe_name(result)
        d['new']=title;d['checked']=bool(title and not needs_folder_translation(title));d['state']='人工修改，等待确认' if title else '未填写译名'
        self.refresh(k)

    def select_all(self):
        for k,d in self.rows.items():
            d['checked']=bool(d['new'] and d['path'].is_dir() and d['new']!=d['path'].name)
            self.refresh(k)

    def _sync_app_paths(self,old,new):
        a=self.app
        for row in self.rows.values():
            row['path']=Path(rebased_path(str(row['path']),old,new))
        for d in a.data.values():
            for name in ('path','duplicate_of'):
                if name in d:d[name]=rebased_path(d[name],old,new)
        for name in ('completed_paths','historical_paths','current_batch_paths'):
            current=getattr(a,name)
            setattr(a,name,{rebased_path(p,old,new) for p in current})
        if a.active_scan_config and isinstance(a.active_scan_config,dict):
            # The selected top-level root is unchanged; no need to change folder.
            pass
        for k in a.order:a.refresh(k)

    def apply(self):
        if self.translating or self._busy():
            messagebox.showwarning('有任务运行','请等待翻译、扫描和改名全部完成后再修改文件夹路径。',parent=self.win)
            return
        selected=[(k,d) for k,d in self.rows.items() if d['checked'] and d['new']]
        # The folder tool must NEVER enqueue file renames or conversions.
        # Re-check containment at execution time in case directories moved.
        outside=[d['path'] for _,d in selected if not is_descendant_directory(d['path'],self.base)]
        if outside:
            messagebox.showerror('路径保护','发现位于所选根目录之外或无效的路径，已拒绝执行。',parent=self.win)
            return
        if not selected:
            messagebox.showinfo('没有任务','请先翻译并勾选要重命名的文件夹。',parent=self.win);return
        selected.sort(key=lambda x:len(x[1]['path'].parts),reverse=True)
        if not messagebox.askyesno('仅更改子文件夹名称',f'将修改 {len(selected)} 个子文件夹的名称。\n不会修改根目录，也不会修改文件夹内任何文件名、内容或后缀。\n内部文件的完整路径会随父目录名称自然变化；历史路径索引将同步。\n是否执行？',parent=self.win):return
        import shutil, datetime
        checkpoint=self.app.checkpoint_path()
        if checkpoint.is_file():
            backup=checkpoint.with_name('任务进度_文件夹改名前备份_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.json')
            shutil.copy2(checkpoint,backup)
        done=0
        for k,d in selected:
            src=d['path'];dst=src.with_name(d['new'])
            try:
                if not is_descendant_directory(src,self.base):raise ValueError('只允许修改所选根目录下的真实子文件夹')
                if dst.parent.resolve()!=src.parent.resolve():raise ValueError('不允许移动到其他父文件夹')
                if dst.exists():raise FileExistsError('同名目标文件夹已存在，不覆盖')
                if d['new'] in SKIP_NAMES:raise ValueError('目标名称为内部保留文件夹名')
                src.rename(dst)
                self._sync_app_paths(src,dst)
                self.app.save_checkpoint(quiet=True,force=True)
                update_sqlite_paths(self.base,src,dst,self.app.write_log)
                done+=1
                d['state']='已改名';d['checked']=False;d['path']=dst
                self.app.write_log(f'文件夹改名成功：{src} -> {dst}')
            except Exception as exc:
                d['state']='失败：'+str(exc)[:100]
                self.app.write_log(f'文件夹改名失败：{src}：{exc}','ERROR')
            self.refresh(k)
        self.app.save_checkpoint(quiet=True,force=True)
        self.status.set(f'完成 {done}/{len(selected)} 个文件夹。失败记录留在列表与运行日志中。')
