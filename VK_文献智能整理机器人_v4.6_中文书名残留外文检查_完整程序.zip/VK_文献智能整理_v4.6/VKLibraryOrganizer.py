# -*- coding: utf-8 -*-
"""Windows GUI: detect document format, extract PDF cover/title, translate titles, preview and rename safely."""
import csv
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
import datetime as dt
import json
import sys
import logging
import traceback
from logging.handlers import RotatingFileHandler
import hashlib
import random
import socket
import os
import queue
import locale
import re
import shutil
import subprocess
import tempfile
import threading
import time
import urllib.error
import urllib.request
import zipfile
from duplicate_detector import Index, fingerprint_pdf, compare
from title_index import TitleIndex
from document_support import extract_nonpdf_evidence, validate_real_pdf
from djvu_title_reader import extract_djvu
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

DEFAULT_DIR = r'C:\Users\35540\Downloads\VK_文献资料'
SUPPORTED = {'.djv', '.pptx', '.xlsx', '.pdf', '.epub', '.djvu', '.mobi', '.azw', '.azw3', '.fb2', '.doc', '.docx', '.rtf', '.txt', '.zip', '.7z', '.rar'}
SKIP_DIRS = {'_整理日志', '_OCR缓存', '疑似重复文献', '_DJVU原件', '_DjVuToy待转换'}
WINDOWS_BAD = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
TRANSLATION_SYSTEM = ("你是俄语、英语学术书籍书目信息的中文译者。根据PDF封面、扉页和书名页摘录，"
                      "判定真实的书名，将书名翻译成简体中文。人名、地名、机构名使用通行中文译名；"
                      "年份保留；不要自行编造书名。只能返回一个JSON对象："
                      '{"title_zh":"中文书名","confidence":"high/medium/low"}。'
                      "证据不足时返回空字符串作为title_zh，严禁虚构具体事实，也不得加入待核实前缀。"
                      "只能返回JSON对象，必须包含title_zh和confidence。不要给说明或Markdown。")


# Mixed-language filenames such as "苏联史 Soviet History" must not be
# treated as translated just because one Chinese character is present.
FOREIGN_SCRIPT = re.compile(r'[\u0400-\u052f]')
LATIN_WORD = re.compile(r'(?<![A-Za-z])[A-Za-z]{2,}(?![A-Za-z])')
UNTRANSLATED_PLACEHOLDERS = ('待核实中文书名-', '待核实书名-', '未知文献')

def untranslated_fragments(value):
    """Detect substantial Cyrillic/Latin text in a *title*, not a file extension.

    Numbers, Roman volume indicators (I, II, III), and 1-3-letter abbreviations
    do not alone trigger retranslation. Candidates remain subject to review.
    """
    stem = str(value or '').strip()
    if FOREIGN_SCRIPT.search(stem):
        return True
    for word in LATIN_WORD.findall(stem):
        # Roman volume numerals are not untranslated English titles.
        if not re.fullmatch(r'[IVXLCDM]+', word, flags=re.I):
            return True
    return False


def complete_chinese_title(value):
    stem = str(value or '').strip()
    if stem.startswith(UNTRANSLATED_PLACEHOLDERS):
        return False
    return bool(re.search(r'[\u4e00-\u9fff]', stem)) and not untranslated_fragments(stem)


def already_chinese_name(filename):
    """Only *fully Chinese* source names are protected; mixed names get audited."""
    from pathlib import PureWindowsPath
    return complete_chinese_title(PureWindowsPath(str(filename)).stem)


def detect_type(path):
    """Detect by signatures (not extension); None means uncertain -> don't alter extension."""
    try:
        with open(path, 'rb') as f:
            sig = f.read(32768)
    except OSError:
        return None
    if sig.startswith(b'%PDF-') or b'%PDF-' in sig[:1024]: return '.pdf'
    if sig.startswith(b'AT&TFORM') or (sig.startswith(b'FORM') and b'DJV' in sig[:20]): return '.djvu'
    if sig.startswith(b'Rar!\x1a\x07'): return '.rar'
    if sig.startswith(b'7z\xbc\xaf\x27\x1c'): return '.7z'
    if sig.startswith(b'PK\x03\x04') or sig.startswith(b'PK\x05\x06'):
        try:
            with zipfile.ZipFile(path) as z:
                names = set(z.namelist())
                if 'mimetype' in names:
                    try:
                        if z.read('mimetype')[:45] == b'application/epub+zip': return '.epub'
                    except Exception: pass
                if '[Content_Types].xml' in names:
                    if any(n.startswith('word/') for n in names): return '.docx'
                    if any(n.startswith('ppt/') for n in names): return '.pptx'
                    if any(n.startswith('xl/') for n in names): return '.xlsx'
        except Exception: pass
        return '.zip'
    if len(sig) > 68 and sig[60:68] == b'BOOKMOBI': return '.mobi'
    if sig.startswith(b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1'): return '.doc'
    head = sig.lstrip(b'\xef\xbb\xbf\x00 \t\r\n').lower()
    if head.startswith(b'{\\rtf'): return '.rtf'
    if b'<fictionbook' in head[:500] or b'<fictionbook' in head[:5000]: return '.fb2'
    # Text formats only when existing extension says TXT (do not rename arbitrary binary to .txt)
    if path.suffix.lower() == '.txt':
        try:
            sig.decode('utf-8-sig')
            if b'\x00' not in sig: return '.txt'
        except UnicodeDecodeError: pass
    return None


def clean_title(title):
    title = WINDOWS_BAD.sub(' ', title or '')
    title = re.sub(r'\s+', ' ', title).strip(' .-_')
    for ch in ['—', '–']:
        title = title.replace(ch, '-')
    return title[:130].rstrip(' .')


def locate_tesseract():
    """Resolve executable without assuming PATH is healthy."""
    candidates = [os.environ.get('TESSERACT_EXE', ''), shutil.which('tesseract')]
    pf = os.environ.get('ProgramFiles', r'C:\Program Files')
    pf86 = os.environ.get('ProgramFiles(x86)', r'C:\Program Files (x86)')
    candidates += [os.path.join(pf, 'Tesseract-OCR', 'tesseract.exe'),
                   os.path.join(pf86, 'Tesseract-OCR', 'tesseract.exe'),
                   r'C:\Tesseract-OCR\tesseract.exe']
    for item in candidates:
        if item and (Path(item).is_file() or (shutil.which(item) is not None)):
            return str(item)
    return None


def ocr_environment(lang='rus+eng'):
    """Require both Russian and English traineddata for bilingual OCR."""
    exe = locate_tesseract()
    if not exe:
        return None, '', '未检测到 Tesseract OCR。请运行 安装OCR环境.bat。'
    tessdata = os.path.join(os.environ.get('LOCALAPPDATA', ''),
                            'VKLibraryOrganizer', 'OCR', 'tessdata')
    if not os.path.isdir(tessdata):
        tessdata = os.path.join(os.path.dirname(exe), 'tessdata')
    try:
        proc = subprocess.run([exe, '--tessdata-dir', tessdata, '--list-langs'], capture_output=True,
                              text=True, errors='replace', timeout=15)
        content = proc.stdout + '\n' + proc.stderr
        installed = set(re.findall(r'(?m)^([a-z][a-z_0-9]+)\s*$', content))
        missing = sorted(set(lang.split('+')) - installed)
        if missing:
            return exe, '', '缺少 OCR 语言包：' + ', '.join(missing) + '。需要 rus.traineddata 和 eng.traineddata。'
        return exe, lang, ''
    except Exception as exc:
        return exe, '', '无法检查俄语 OCR 环境：' + str(exc)[:140]


def selected_page_indices(total, head_pages=6, tail_pages=6):
    """Inspect both ends of a book, no duplicates for short PDFs."""
    if total <= 0:
        return []
    head = min(total, max(1, min(int(head_pages), 30)))
    tail = min(total, max(0, min(int(tail_pages), 30)))
    return sorted(set(range(head)) | set(range(max(0, total-tail), total)))


def extract_pdf(path, ocr=False, tesseract=None, lang='rus+eng', max_pages=6,
                tail_pages=6, ocr_mode='auto'):
    try:
        import fitz
    except ImportError:
        return '', '', '缺少 PyMuPDF（先运行 Install.bat）'
    excerpts, meta_title, ocr_pages, ocr_errors = [], '', 0, []
    exe, enabled_lang, env_note = (None, '', '')
    if ocr:
        exe, enabled_lang, env_note = ocr_environment(lang)
    try:
        with fitz.open(path) as doc:
            if doc.is_encrypted: return '', '', 'PDF 已加密，无法读取'
            md = doc.metadata or {}
            meta_title = (md.get('title') or '').strip()
            indices = selected_page_indices(len(doc), max_pages, tail_pages)
            for i in indices:
                page = doc[i]
                text = page.get_text('text', sort=True).strip()
                density = len(re.sub(r'\s', '', text))
                must_ocr = ocr and (ocr_mode == 'all' or density < 100)
                if must_ocr and exe and enabled_lang:
                    try:
                        pix = page.get_pixmap(matrix=fitz.Matrix(2.4, 2.4), alpha=False)
                        with tempfile.TemporaryDirectory(prefix='vk_ocr_') as folder:
                            image_path = os.path.join(folder, 'page.png')
                            pix.save(image_path)
                            tessdata = os.path.join(os.environ.get('LOCALAPPDATA', ''),
                                                    'VKLibraryOrganizer', 'OCR', 'tessdata')
                            if not os.path.isdir(tessdata):
                                tessdata = os.path.join(os.path.dirname(exe), 'tessdata')
                            result = subprocess.run([exe, image_path, 'stdout',
                                                     '--tessdata-dir', tessdata,
                                                     '-l', enabled_lang, '--psm', '3'],
                                                    capture_output=True, timeout=120)
                            if result.returncode == 0:
                                recognized = result.stdout.decode('utf-8', errors='replace').strip()
                                if len(recognized) > len(text) or ocr_mode == 'all':
                                    text = recognized or text
                                ocr_pages += 1
                            else:
                                ocr_errors.append(f'第{i+1}页OCR失败（返回码{result.returncode}）')
                    except (OSError, subprocess.TimeoutExpired, ValueError) as exc:
                        ocr_errors.append(f'第{i+1}页OCR异常：{str(exc)[:80]}')
                if text:
                    zone = '开头' if i < int(max_pages) else '结尾'
                    # The first and last few pages are most informative; cap per page.
                    excerpts.append(f'[全书{len(doc)}页 | {zone}第{i+1}页]\n{text[:2400]}')
            notes = [f'已检查首尾共{len(indices)}页（开头{max_pages}页+结尾{tail_pages}页）']
            if ocr:
                if env_note: notes.append(env_note)
                if enabled_lang: notes.append(f'OCR完成{ocr_pages}页（{enabled_lang}）')
                if ocr_errors: notes.append('; '.join(ocr_errors[:3]))
            # Allow room for beginning AND end, even with long texts.
            early = [x for x in excerpts if ' | 开头第' in x]
            late = [x for x in excerpts if ' | 结尾第' in x]
            combined = ('\n\n'.join(early)[:9500] + '\n\n' + '\n\n'.join(late)[:9500]).strip()
            return combined, meta_title, '; '.join(notes)
    except Exception as exc:
        return '', '', f'PDF 读取失败：{str(exc)[:120]}'



def extract_first_page_title(path, kind, ocr=True, lang='rus+eng', ocr_mode='auto', log=None):
    """Read only the first document page; never convert DJVU into PDF.

    This is a fallback evidence source for untranslated titles, not a promise
    that every first page contains a bibliographic title.
    """
    kind = (kind or path.suffix).lower()
    if kind in ('.djvu', '.djv'):
        return extract_djvu(path, ocr=ocr, lang=lang, max_pages=1,
                            tail_pages=0, ocr_mode=ocr_mode, log=log)
    if kind == '.pdf':
        return extract_pdf(path, ocr=ocr, lang=lang, max_pages=1,
                           tail_pages=0, ocr_mode=ocr_mode)
    return extract_nonpdf_evidence(path, kind)


def fallback_chinese_name(path, original_title=''):
    """Never invent or prefix an unverified Chinese title.

    A failed OCR/translation leaves the original basename intact; only a
    verified format correction may be proposed separately.
    """
    return ''


def russian_title_candidates(text, limit=14):
    """Extract *evidence candidates* from cover/title/copyright pages.

    This never fabricates a bibliographic title. A language model still decides
    which (if any) candidate is the book title.
    """
    lines = []
    excluded = ('РОССИЙСКАЯ АКАДЕМИЯ', 'ИНСТИТУТ ', 'МИНИСТЕРСТВО ',
                'УДК ', 'ББК ', 'ISBN ', 'ОГЛАВЛЕНИЕ', 'СОДЕРЖАНИЕ',
                'ПРЕДИСЛОВИЕ', 'ВВЕДЕНИЕ', 'ИЗДАТЕЛЬСТВО ', 'МОСКВА',
                'САНКТ-ПЕТЕРБУРГ', 'ГЛАВА ', 'ЧАСТЬ ', 'СТРАНИЦА ')
    for line in (text or '').splitlines():
        line = re.sub(r'\s+', ' ', line).strip(' \t:;.,–—-')
        if not line or line.startswith('[') or len(line) < 9 or len(line) > 160:
            continue
        if len(re.findall('[А-Яа-яЁё]', line)) < 7:
            continue
        if any(line.upper().startswith(prefix) for prefix in excluded):
            continue
        if re.fullmatch(r'[А-ЯЁ][а-яё]+\s+[А-ЯЁ]\.?\s*[А-ЯЁ]?\.?',line):
            continue
        if re.search(r'\.{4,}\s*\d+', line):
            continue
        if re.fullmatch(r'(?:[А-ЯЁ]\.\s*){1,3}[А-ЯЁ][а-яё-]+', line):
            continue
        if line not in lines:
            lines.append(line)
        if len(lines) >= limit:
            break
    return lines


def source_title_guess(path, metadata, text):
    if metadata and len(metadata) <= 160 and not re.search(r'^(untitled|document|scan|pdf|microsoft|acrobat)', metadata, re.I):
        return re.sub(r'\s+', ' ', metadata)
    russian = russian_title_candidates(text)
    if russian:
        return ' / '.join(russian[:3])[:180]
    # Find likely lines from early cover pages, not random whole paragraphs
    lines = [re.sub(r'\s+', ' ', line).strip() for line in text.splitlines()]
    candidates = [line for line in (lines[:100] + lines[-100:]) if 8 <= len(line) <= 125
                  and not line.startswith('[第') and not re.fullmatch(r'[\d\s,.:()–—-]+', line)]
    if candidates:
        return ' / '.join(candidates[:2])[:145]
    return path.stem[:145]


def parse_chinese_title(answer):
    """Accept fenced JSON, embedded JSON, title-only text and common key variants."""
    raw = (answer or '').strip()
    if not raw:
        return ''
    raw = re.sub(r'^```(?:json)?\s*|\s*```$', '', raw, flags=re.I).strip()
    candidates = [raw]
    first = raw.find('{')
    last = raw.rfind('}')
    if first >= 0 and last > first:
        candidates.append(raw[first:last+1])
    for item in candidates:
        try:
            obj = json.loads(item)
        except (ValueError, TypeError):
            continue
        if isinstance(obj, dict):
            for key in ('title_zh', 'chinese_title', 'title_cn', 'translated_title', 'translated_name', '书名', '中文书名', 'title'):
                value = obj.get(key)
                if isinstance(value, str):
                    title = clean_title(value)
                    if complete_chinese_title(title):
                        return title
    # Fall back to a single Chinese title, avoiding explanatory paragraphs.
    lines = [x.strip(' \t\r\n\"“”`') for x in raw.splitlines() if x.strip()]
    if len(lines) == 1:
        line = re.sub(r'^(?:中文书名|书名|译名|title_zh)\s*[:：]\s*', '', lines[0], flags=re.I)
        line = line.strip(' \t\"“”')
        if 2 <= len(line) <= 110 and complete_chinese_title(line) and not line.startswith('{'):
            return clean_title(line)
    return ''


def translate_title(api_key, model, text, metadata, filename):
    """Three evidence-aware attempts: full front/back, condensed bibliographic clues, basename.

    Avoid fabricated Chinese book titles. Failures are recorded for reprocessing.
    """
    key = (api_key or '').strip()
    if not key:
        return '', '缺少DeepSeek API Key：未完成翻译，请配置后补译'
    if not ((text or '').strip() or (metadata or '').strip() or (filename or '').strip()):
        return '', '等待处理：缺少可识别的书名信息'
    selected = (model or '').strip() or 'deepseek-flash'
    excerpt = (text or '')
    full = (f'原文件名：{filename}\nPDF元数据：{(metadata or "")[:350]}\n'
            f'开头和结尾页文字：\n{excerpt[:18000]}\n'
            '请核对扉页、封面和书尾版权信息，只输出有依据的简体中文书名。')
    # Keep separate start/end evidence in shorter fallback requests.
    segments = excerpt.split('\n\n')
    condensed = '\n'.join([x[:500] for x in segments[:7] + segments[-7:]])[:6000]
    russian_lines = russian_title_candidates(excerpt)
    russian_evidence = '\n'.join(russian_lines[:14])
    focused_prompt = (
        '任务：先识别资料中实际存在的俄语书名，再将该书名翻译为简体中文。'
        '不要把作者、机构、出版社、丛书名、章节标题当成书名。'
        '如果第一页只有作者或机构，请结合后续封面、扉页和版权页判断。'
        '必须输出JSON对象：{"title_ru":"实际俄文书名","title_zh":"准确中文译名"}。'
        '若材料确实不足，字段可以为空，绝对不要编造书名。\n'
        f'文件名：{filename}\n元数据：{metadata or ""}\n'
        f'疑似俄文标题行（只是候选，需核验）：\n{russian_evidence}\n'
        f'书籍前后文字证据：\n{excerpt[:6800]}'
    )
    stages = []
    if untranslated_fragments(Path(filename).stem) and re.search(r'[\u4e00-\u9fff]', Path(filename).stem):
        stages.append(('中外文混合名称补译',
             '下列书籍文件名包含中文和仍未翻译的俄文/英文。请结合现有书内证据，'
             '把外语书名、专名、英文副标题等翻译或音译为简体中文，保留已有准确的中文部分、数字与年份；'
             '不要将任何明显俄文或英文单词遗留在最终中文书名里。不要编造原书没有的信息。'
             '只返回JSON：{"title_zh":"完整中文书名"}。\n'
             f'混合文件名：{filename}\n书内证据：{excerpt[:3000]}'))
    stages.extend([
        ('俄文书名定位与翻译', focused_prompt),
        ('首尾全文', full),
        ('首尾精简', f'文件名：{filename}\n元数据：{metadata}\n首尾内容：{condensed}\n请返回中文书名。'),
        ('仅文件名', f'请把以下俄语或转写的文献文件名译成简体中文书名：{filename}。'
                     '如果无法确定完整书名，只翻译可确认的语义，不虚构出版社、作者和年份。')
    ])
    last_error = ''
    for stage_name, prompt in stages:
        payload = json.dumps({
            'model': selected,
            'messages': [{'role': 'system', 'content': TRANSLATION_SYSTEM},
                         {'role': 'user', 'content': prompt}],
            'temperature': 0.0, 'max_tokens': 550
        }, ensure_ascii=False).encode('utf-8')
        for attempt in range(2):
            req = urllib.request.Request('https://api.deepseek.com/chat/completions', data=payload,
                     headers={'Authorization': 'Bearer ' + key,
                              'Content-Type': 'application/json', 'Accept': 'application/json',
                              'User-Agent': 'VKLibraryOrganizer/1.8'}, method='POST')
            delay = min(16, 1.5 * (2 ** attempt) + random.random())
            try:
                with urllib.request.urlopen(req, timeout=35) as response:
                    result = json.load(response)
                choices = result.get('choices') or []
                answer = choices[0].get('message', {}).get('content') if choices else ''
                title = parse_chinese_title(answer or '')
                if complete_chinese_title(title):
                    return title, f'已生成中文候选（{stage_name}；请核对原书）'
                last_error = '模型响应未包含有效的中文书名'
                break  # Use next, shorter prompt
            except urllib.error.HTTPError as exc:
                try:
                    detail = exc.read(500).decode('utf-8', errors='replace')
                except Exception:
                    detail = ''
                last_error = f'HTTP {exc.code}：' + re.sub(r'\s+', ' ', detail)[:130]
                if exc.code in (400, 401, 402, 403, 404):
                    return '', '等待处理：' + last_error + '（需检查密钥、余额或模型）'
                if exc.code not in (408, 409, 429, 500, 502, 503, 504):
                    break
                retry_after = exc.headers.get('Retry-After', '')
                if retry_after.isdecimal():
                    delay = min(30, float(retry_after))
            except (urllib.error.URLError, TimeoutError, socket.timeout, ConnectionError) as exc:
                last_error = '网络连接异常：' + str(exc)[:120]
            except (ValueError, KeyError, IndexError, TypeError) as exc:
                last_error = 'API 数据异常：' + str(exc)[:120]
                break
            if attempt < 1:
                time.sleep(delay)
    return '', '等待重新处理：' + (last_error or '未取得可信中文书名')


def unique_destination(source, stem, ext, reserved=None):
    reserved = reserved if reserved is not None else set()
    stem = clean_title(stem) or source.stem
    for n in range(1, 100000):
        suffix = '' if n == 1 else f' ({n})'
        dest = source.with_name(stem[:max(12, 140-len(suffix))] + suffix + ext)
        norm = str(dest).casefold()
        if norm == str(source).casefold() or (not dest.exists() and norm not in reserved):
            reserved.add(norm)
            return dest
    raise RuntimeError('过多同名文件')


class App:
    def __init__(self, root):
        self.root = root
        self.root.title('VK 文献智能整理 v4.1｜修复文件夹翻译')
        self.root.geometry('1210x735')
        self.root.minsize(900, 590)
        self.msg = queue.Queue()
        self.run_logger = None
        self.log_path = None
        self.log_window = None
        self.log_text = None
        self.pending_log_lines = []
        self.data = {}
        self.order = []
        self.busy = False
        # Same GUI process, two independent workers; never use global busy for these lanes.
        self.rename_running = False
        self.djvu_running = False  # legacy flag, permanently disabled
        self.rename_resume = threading.Event(); self.rename_resume.set()
        self.djvu_resume = threading.Event(); self.djvu_resume.set()
        self.rename_skip = threading.Event()
        self.djvu_skip = threading.Event()
        self.index_mutex = threading.RLock()
        self.destination_mutex = threading.RLock()
        self.destination_reservations = set()
        self.rename_status = tk.StringVar(value='文件改名：待命（包含DJVU）')
        self.job_mode = None
        self.resume_event = threading.Event()
        self.resume_event.set()
        self.skip_event = threading.Event()
        self.current_path = None
        self.completed_paths = set()
        self.untranslated_keys = []
        self.active_scan_config = None
        self.checkpoint_lock = threading.Lock()
        self.parallel_workers = tk.StringVar(value='4')
        # Restrict API and OCR concurrency independently; no DJVU conversion tasks.
        self.api_slots = threading.BoundedSemaphore(4)
        self.ocr_slots = threading.BoundedSemaphore(2)
        self.last_checkpoint_save = 0.0
        self.new_files_only = tk.BooleanVar(value=True)
        self.current_batch_paths = set()  # Snapshot of this scan's genuinely new files
        self.historical_paths = set()     # Loaded from saved checkpoint, including untranslated
        self.active_lock = threading.Lock()
        self.active_files = {}  # currently running scan paths
        self.skip_requested = set()
        self.folder = tk.StringVar(value=DEFAULT_DIR)
        self.key = tk.StringVar(value=os.environ.get('DEEPSEEK_API_KEY', ''))
        self.model = tk.StringVar(value='deepseek-flash')
        self.use_api = tk.BooleanVar(value=True)
        self.use_ocr = tk.BooleanVar(value=True)
        self.ocr_lang = tk.StringVar(value='rus+eng')
        self.ocr_pages = tk.StringVar(value='10')
        self.tail_pages = tk.StringVar(value='10')
        self.ocr_mode = tk.StringVar(value='auto')
        self.recursive = tk.BooleanVar(value=False)
        self.include_nonpdf = tk.BooleanVar(value=True)
        self.detect_duplicates = tk.BooleanVar(value=True)
        self.shutdown_after = tk.BooleanVar(value=False)
        self.status = tk.StringVar(value='就绪。先扫描，再检查中文候选名，最后点击“应用重命名”。')
        self.progress = tk.DoubleVar(value=0)
        self.build()
        self.root.after(90, self.poll)

    def install_patch(self):
        """Launch the external verified updater after closing the GUI."""
        if self.busy or self.rename_running or self.djvu_running:
            messagebox.showwarning('任务仍在执行', '请先暂停并等待当前文件处理结束，然后保存进度、退出程序，再安装补丁。')
            return
        package = filedialog.askopenfilename(title='选择 VK 文献整理机器人补丁包', filetypes=[('补丁包 ZIP', '*.zip')])
        if not package:
            return
        here = Path(__file__).resolve().parent
        try:
            import patch_manager
            info = patch_manager.inspect_patch(Path(package), here)
        except Exception as exc:
            messagebox.showerror('补丁校验失败', str(exc))
            return
        if not messagebox.askyesno('确认安装补丁', '准备安装：' + info['version'] + '\n补丁文件数：' + str(len(info['files'])) + '\n将备份被替换的程序文件。\n\n请确保已保存当前任务进度。安装将关闭程序。'):
            return
        try:
            self.save_checkpoint(quiet=True)
        except Exception:
            pass
        try:
            subprocess.Popen([sys.executable, str(here/'patch_manager.py'), '--apply', str(Path(package).resolve()), '--target', str(here), '--wait-pid', str(os.getpid())], cwd=str(here), creationflags=getattr(subprocess,'CREATE_NEW_CONSOLE',0))
        except Exception as exc:
            messagebox.showerror('无法启动补丁安装器', str(exc))
            return
        self.root.destroy()

    def open_folder_manager(self):
        from folder_rename import FolderManager
        FolderManager(self)

    def build(self):
        outer = ttk.Frame(self.root, padding=12)
        outer.pack(fill='both', expand=True)
        folder_frame = ttk.LabelFrame(outer, text='1. 文献目录', padding=8)
        folder_frame.pack(fill='x', pady=(0, 8))
        ttk.Entry(folder_frame, textvariable=self.folder).pack(side='left', fill='x', expand=True, padx=(0, 8))
        ttk.Button(folder_frame, text='浏览目录…', command=self.browse).pack(side='left')
        ttk.Button(folder_frame, text='仅翻译下级文件夹名…', command=self.open_folder_manager).pack(side='left', padx=6)
        ttk.Button(folder_frame, text='实时任务日志', command=self.open_log_window).pack(side='left', padx=8)
        ttk.Label(folder_frame, text='同时处理文件数：').pack(side='left', padx=(12, 3))
        ttk.Spinbox(folder_frame, from_=1, to=128, textvariable=self.parallel_workers, width=6).pack(side='left')
        ttk.Checkbutton(folder_frame, text='仅处理新增文件（最新优先）', variable=self.new_files_only).pack(side='left', padx=(10, 0))
        options = ttk.LabelFrame(outer, text='2. 文件识别及书名翻译设置', padding=8)
        options.pack(fill='x', pady=(0, 8))
        top = ttk.Frame(options)
        top.pack(fill='x')
        ttk.Checkbutton(top, text='翻译所有非中文文件名（DeepSeek）', variable=self.use_api).pack(side='left', padx=(0, 15))
        ttk.Checkbutton(top, text='启用扫描版 OCR', variable=self.use_ocr).pack(side='left', padx=(0, 15))
        ttk.Checkbutton(top, text='包含子文件夹', variable=self.recursive).pack(side='left', padx=(0, 15))
        ttk.Checkbutton(top, text='扫描各种文献格式', variable=self.include_nonpdf).pack(side='left')
        ttk.Checkbutton(top, text='全格式书名优先查重（同名再检查前十页）', variable=self.detect_duplicates).pack(side='left', padx=10)
        ocrbar = ttk.Frame(options)
        ocrbar.pack(fill='x', pady=(8, 0))
        ttk.Label(ocrbar, text='OCR语言：俄语+英语 (rus+eng)').pack(side='left', padx=(0, 15))
        ttk.Label(ocrbar, text='扫描开头 N 页：').pack(side='left')
        ttk.Spinbox(ocrbar, from_=1, to=30, textvariable=self.ocr_pages, width=5).pack(side='left', padx=(3, 15))
        ttk.Label(ocrbar, text='结尾 N 页：').pack(side='left')
        ttk.Spinbox(ocrbar, from_=1, to=30, textvariable=self.tail_pages, width=5).pack(side='left', padx=(3, 15))
        ttk.Radiobutton(ocrbar, text='只识别文字少的页面', variable=self.ocr_mode, value='auto').pack(side='left', padx=(0, 10))
        ttk.Radiobutton(ocrbar, text='所有选定页都 OCR', variable=self.ocr_mode, value='all').pack(side='left', padx=(0, 12))
        ttk.Button(ocrbar, text='检查 OCR 环境', command=self.check_ocr).pack(side='left')
        bottom = ttk.Frame(options)
        bottom.pack(fill='x', pady=(10, 0))
        ttk.Label(bottom, text='DeepSeek API Key：').pack(side='left')
        ttk.Entry(bottom, textvariable=self.key, show='*', width=46).pack(side='left', padx=(3, 12))
        ttk.Label(bottom, text='模型：').pack(side='left')
        ttk.Entry(bottom, textvariable=self.model, width=22).pack(side='left')
        ttk.Label(bottom, text='密钥仅用于本次运行，不保存到文件', foreground='#666').pack(side='left', padx=14)

        actions = ttk.Frame(outer)
        actions.pack(fill='x', pady=(0, 8))
        self.scan_button = ttk.Button(actions, text='扫描文件 + 生成中文候选书名', command=self.start_scan)
        self.scan_button.pack(side='left', padx=(0, 8))
        self.apply_button = ttk.Button(actions, text='批量改名（含 DJVU，不转换）', command=self.start_apply)
        self.apply_button.pack(side='left', padx=(0, 8))
        self.fast_apply_button = ttk.Button(actions, text='⚡ 快速批量改名', command=self.start_fast_apply)
        self.fast_apply_button.pack(side='left', padx=(0, 8))
        lanes = ttk.Frame(outer)
        lanes.pack(fill='x', pady=(0, 8))
        ttk.Label(lanes, textvariable=self.rename_status, width=42).pack(side='left')
        ttk.Button(lanes, text='暂停改名', command=lambda: self.lane_control('rename','pause')).pack(side='left', padx=2)
        ttk.Button(lanes, text='继续改名', command=lambda: self.lane_control('rename','resume')).pack(side='left', padx=2)
        ttk.Button(lanes, text='跳过下一个改名', command=lambda: self.lane_control('rename','skip')).pack(side='left', padx=2)
        control_bar = ttk.Frame(outer)
        control_bar.pack(fill='x', pady=(0, 8))
        self.pause_button = ttk.Button(control_bar, text='⏸ 暂停（当前文件完成后）', command=self.pause_job, state='disabled')
        self.pause_button.pack(side='left', padx=(0, 7))
        self.resume_button = ttk.Button(control_bar, text='▶ 继续', command=self.resume_job, state='disabled')
        self.resume_button.pack(side='left', padx=(0, 7))
        self.skip_button = ttk.Button(control_bar, text='⏭ 跳过当前文件', command=self.skip_current, state='disabled')
        self.skip_button.pack(side='left', padx=(0, 7))
        ttk.Button(control_bar, text='跳过选中文件', command=self.skip_selected).pack(side='left', padx=(0, 7))
        ttk.Button(control_bar, text='💾 保存进度', command=self.save_checkpoint).pack(side='left', padx=(0, 7))
        ttk.Button(control_bar, text='📂 载入上次进度', command=self.load_checkpoint).pack(side='left', padx=(0, 7))
        ttk.Button(control_bar, text='🔎 检查中文名残留外文', command=self.audit_untranslated).pack(side='left', padx=(0, 7))
        ttk.Button(control_bar, text='任务日志…', command=self.open_log_window).pack(side='left', padx=(0, 7))
        ttk.Button(control_bar, text='安装补丁…', command=self.install_patch).pack(side='left', padx=(0, 7))
        ttk.Label(control_bar, text='并发扫描暂停后可编辑已完成书名；继续后恢复排队任务。').pack(side='left')
        self.export_button = ttk.Button(actions, text='导出预览 CSV', command=self.export_csv)
        self.export_button.pack(side='left', padx=(0, 8))
        ttk.Button(actions, text='一键勾选全部', command=self.select_all_actionable).pack(side='left', padx=(0, 8))
        ttk.Button(actions, text='一键勾选全部外语书名', command=self.select_all_foreign_renames).pack(side='left', padx=(0, 8))
        ttk.Button(actions, text='选中/取消一行', command=self.toggle_selected).pack(side='left', padx=(0, 8))
        ttk.Button(actions, text='编辑中文书名', command=self.edit_selected).pack(side='left', padx=(0,8))
        self.retry_button = ttk.Button(actions, text='补译未完成及中外文混合书名', command=self.retry_untranslated)
        self.retry_button.pack(side='left', padx=(0, 8))
        self.duplicate_button = ttk.Button(actions, text='移动疑似重复文件', command=self.start_move_duplicates)
        self.duplicate_button.pack(side='left', padx=(0, 8))
        ttk.Button(actions, text='检查异常PDF', command=self.start_pdf_audit).pack(side='left', padx=(0,8))
        ttk.Checkbutton(actions, text='整理操作完成后关机（需确认）', variable=self.shutdown_after).pack(side='left')
        ttk.Label(outer, text='3. 预览（双击一行可编辑中文书名；首列的“✓”代表将修改；原文件不会在扫描阶段被修改）').pack(anchor='w')
        frame = ttk.Frame(outer)
        frame.pack(fill='both', expand=True, pady=(5, 7))
        cols = ('mark', 'name', 'kind', 'source', 'zh', 'new', 'duplicate', 'state')
        self.tree = ttk.Treeview(frame, columns=cols, show='headings', selectmode='extended')
        headers = ('选择', '当前文件名', '识别格式', '识别的原书名', '中文候选书名', '拟改为', '前十页查重', '状态')
        widths = (50, 220, 80, 210, 210, 250, 220, 230)
        for col, text, width in zip(cols, headers, widths):
            self.tree.heading(col, text=text)
            self.tree.column(col, width=width, minwidth=50, stretch=col not in ('mark', 'kind'))
        ys = ttk.Scrollbar(frame, orient='vertical', command=self.tree.yview)
        xs = ttk.Scrollbar(frame, orient='horizontal', command=self.tree.xview)
        self.tree.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        self.tree.grid(row=0, column=0, sticky='nsew')
        ys.grid(row=0, column=1, sticky='ns')
        xs.grid(row=1, column=0, sticky='ew')
        frame.grid_rowconfigure(0, weight=1)
        frame.grid_columnconfigure(0, weight=1)
        self.tree.bind('<Double-1>', lambda _: self.edit_selected())
        self.tree.bind('<space>', lambda _: self.toggle_selected())
        self.bar = ttk.Progressbar(outer, variable=self.progress, maximum=100)
        self.bar.pack(fill='x')
        ttk.Label(outer, textvariable=self.status, wraplength=1150).pack(fill='x', pady=(5, 0))
        ttk.Label(outer, text='注意：AI 识别的书名需要人工核对；只有按下“应用重命名”才会修改文件。'
                  ' PDF 内容不更改，自动生成 CSV 操作日志。', foreground='#666').pack(anchor='w', pady=(7, 0))

    def configure_run_logger(self, directory=None):
        """Set up an append-only disk log in the selected library directory.

        Log writes are thread-safe. Never include secrets or full API payloads.
        """
        dest = Path(directory or self.folder.get()) / '_整理日志' / '任务运行.log'
        dest.parent.mkdir(parents=True, exist_ok=True)
        if self.log_path == dest and self.run_logger:
            return
        logger = logging.getLogger('vk_library_organizer_' + str(id(self)))
        logger.setLevel(logging.INFO)
        logger.propagate = False
        for handler in list(logger.handlers):
            logger.removeHandler(handler)
            handler.close()
        handler = RotatingFileHandler(dest, maxBytes=8*1024*1024, backupCount=4, encoding='utf-8')
        handler.setFormatter(logging.Formatter('%(asctime)s [%(levelname)s] %(message)s', '%Y-%m-%d %H:%M:%S'))
        logger.addHandler(handler)
        self.log_path = dest
        self.run_logger = logger
        self.write_log('日志已启用；本次扫描目录：' + str(directory or self.folder.get()))

    def write_log(self, message, level='INFO', exc_info=False):
        """Can be called from worker threads; queue GUI updates for Tk main thread."""
        message = str(message).replace('\r', ' ').strip()
        if self.run_logger:
            method = getattr(self.run_logger, level.lower(), self.run_logger.info)
            method(message, exc_info=exc_info)
        stamp = dt.datetime.now().strftime('%H:%M:%S')
        self.msg.put(('log', f'{stamp} [{level}] {message}'))

    def open_log_window(self):
        if self.log_window is not None and self.log_window.winfo_exists():
            self.log_window.lift()
            return
        win = tk.Toplevel(self.root)
        win.title('实时任务日志｜V3.0')
        win.geometry('1030x540')
        self.log_window = win
        head = ttk.Frame(win, padding=8)
        head.pack(fill='x')
        ttk.Label(head, text='日志文件：' + str(self.log_path or '(开始扫描后自动创建)'), wraplength=730).pack(side='left', fill='x', expand=True)
        ttk.Button(head, text='打开日志目录', command=self.open_log_folder).pack(side='right', padx=4)
        ttk.Button(head, text='复制日志', command=self.copy_log).pack(side='right', padx=4)
        frame = ttk.Frame(win, padding=(8,0,8,8))
        frame.pack(fill='both', expand=True)
        area = tk.Text(frame, wrap='word', font=('Consolas', 10), state='disabled')
        scroll = ttk.Scrollbar(frame, orient='vertical', command=area.yview)
        area.configure(yscrollcommand=scroll.set)
        area.pack(side='left', fill='both', expand=True)
        scroll.pack(side='right', fill='y')
        self.log_text = area
        if self.log_path and self.log_path.is_file():
            try:
                with open(self.log_path, encoding='utf-8', errors='replace') as f:
                    recent = f.readlines()[-400:]
                self.append_log_to_window(''.join(recent))
            except OSError as exc:
                self.append_log_to_window('日志读取失败：' + str(exc) + '\n')
        else:
            self.append_log_to_window('启动扫描后将自动写入实时日志。\n')
        def close():
            self.log_window = None
            self.log_text = None
            win.destroy()
        win.protocol('WM_DELETE_WINDOW', close)

    def append_log_to_window(self, line):
        if self.log_text is None or not self.log_text.winfo_exists(): return
        self.log_text.configure(state='normal')
        self.log_text.insert('end', line)
        if int(self.log_text.index('end-1c').split('.')[0]) > 3000:
            self.log_text.delete('1.0', '400.0')
        self.log_text.see('end')
        self.log_text.configure(state='disabled')

    def copy_log(self):
        if self.log_path and self.log_path.is_file():
            text = self.log_path.read_text(encoding='utf-8', errors='replace')[-60000:]
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            self.status.set('已复制最近 60000 字符日志，请发送前检查是否包含隐私信息。')

    def open_log_folder(self):
        folder = self.log_path.parent if self.log_path else Path(self.folder.get()) / '_整理日志'
        folder.mkdir(parents=True, exist_ok=True)
        if sys.platform == 'win32': os.startfile(str(folder))
        else: self.status.set('日志目录：' + str(folder))

    def check_ocr(self):
        exe, lang, note = ocr_environment(self.ocr_lang.get())
        if not exe or not lang:
            messagebox.showwarning('OCR 检测', note)
        else:
            messagebox.showinfo('OCR 检测', f'OCR 程序：{exe}\n可用语言：{lang}\n' + (note or '环境正常。'))

    def browse(self):
        if self.rename_running or self.djvu_running or self.busy:
            messagebox.showwarning('任务正在运行', '请在两个队列全部完成后再切换文件夹。')
            return
        picked = filedialog.askdirectory(initialdir=self.folder.get() if Path(self.folder.get()).exists() else str(Path.home()))
        if picked: self.folder.set(picked)

    def checkpoint_path(self):
        return Path(self.folder.get()) / '_整理日志' / '任务进度_v2.7.json'

    def save_checkpoint(self, quiet=False, force=False):
        """Atomic persistence; never save API keys."""
        try:
            now = time.monotonic()
            if quiet and not force and now - self.last_checkpoint_save < 3:
                return
            dest = self.checkpoint_path()
            dest.parent.mkdir(parents=True, exist_ok=True)
            payload = {'version': 1, 'folder': str(Path(self.folder.get()).resolve()),
                       'completed_paths': sorted(self.completed_paths),
                       'pending_new_paths': sorted(self.current_batch_paths),
                       'rows': [self.data[k] for k in self.order],
                       'scan_config': {k: v for k, v in (self.active_scan_config or {}).items() if k != 'key'},
                       'saved_at': dt.datetime.now().isoformat(timespec='seconds')}
            tmp = dest.with_suffix('.json.tmp')
            with self.checkpoint_lock:
                with open(tmp, 'w', encoding='utf-8') as f:
                    json.dump(payload, f, ensure_ascii=False, indent=2)
                os.replace(tmp, dest)
            self.last_checkpoint_save = time.monotonic()
            if not quiet:
                self.status.set('进度已保存：' + str(dest))
        except Exception as exc:
            if not quiet: messagebox.showerror('保存失败', str(exc))
            self.write_log('保存进度失败：' + repr(exc), 'ERROR')

    @staticmethod
    def missing_chinese_title(d):
        """Audit empty, foreign-only and partially translated Chinese filenames.

        A complete-Chinese original is protected, regardless of an old failed
        proposal. A mixed original needs a complete Chinese target title.
        """
        from pathlib import PureWindowsPath
        source = PureWindowsPath(str(d.get('path', ''))).stem
        if already_chinese_name(source):
            return False
        return not complete_chinese_title(d.get('zh') or '')

    def audit_untranslated(self, silent=False):
        """Check ALL recovered entries, including completed and DJVU rows.

        Does not re-OCR or call an API, and never renames anything itself.
        """
        missing = []
        for k in self.order:
            d = self.data[k]
            if not Path(d.get('path', '')).is_file():
                continue
            if self.missing_chinese_title(d):
                missing.append(k)
                d['protected'] = False
                d['checked'] = False  # No renaming without a valid title
                prior = str(d.get('state') or '')
                if '需补译' not in prior:
                    d['state'] = '需补译（中文名称可能含未翻译外文或缺少中文译名）；' + prior
                self.refresh(k)
        self.untranslated_keys = missing
        self.save_checkpoint(quiet=True)
        if not silent:
            if missing and not self.new_files_only.get():
                self.tree.selection_set(missing)
                self.tree.see(missing[0])
                messagebox.showinfo('未翻译检查',
                    f'已检查 {len(self.order)} 条记录，发现 {len(missing)} 个未译全（含中外文混合）的书名。\n'
                    '已标记并选中，不会修改文件。\n'
                    '填写 API Key 后点击“重试未完成翻译”即可批量补译。')
            else:
                messagebox.showinfo('未翻译检查', '当前记录无空白译名或明显中外文混合书名。')
        return missing

    @staticmethod
    def normalize_name_only_row(record):
        """Migrate old DJVU conversion tasks to *rename only* without changing source bytes.

        May be applied to any loaded in-memory row. Existing OCR snippets are preserved.
        """
        d = dict(record)
        source = Path(str(d.get('path') or ''))
        actual = detect_type(source) if source.is_file() else None
        suffix = actual or source.suffix.lower()
        if suffix in ('.djvu', '.djv'):
            # Preserve extension spelling from the original where valid.
            suffix = source.suffix if source.suffix.lower() in ('.djvu', '.djv') else '.djvu'
            d['kind'] = suffix
            d['source_kind'] = '.djvu'
            d['convert'] = False
            d['ext_fix'] = False
            title = str(d.get('zh') or '').strip()
            stem = clean_title(title) if title else source.stem
            d['new'] = stem + suffix
            if record.get('convert') or str(record.get('kind', '')).lower() == '.pdf':
                # Legacy conversion candidate: auto-select only when a real Chinese title exists.
                d['checked'] = bool(title and not already_chinese_name(source.name) and source.name != d['new'] and not d.get('unverified'))
            else:
                d['checked'] = bool(record.get('checked'))
            if '转换' in str(d.get('state') or '') and '新版仅翻译并重命名' not in str(d.get('state') or ''):
                d['state'] = str(d.get('state') or '') + '；新版仅翻译并重命名，不转换DJVU'
        else:
            d['convert'] = False
            # Older checkpoints may still contain proposed extension repairs.
            # This release changes the stem only, for every supported format.
            d['kind'] = source.suffix
            title = str(d.get('zh') or '').strip()
            d['new'] = (clean_title(title) if title else source.stem) + source.suffix
            d['ext_fix'] = False
        return d

    def load_checkpoint(self):
        try:
            self.configure_run_logger()
            self.write_log('载入历史进度：' + str(self.checkpoint_path()))
        except Exception as exc:
            messagebox.showwarning('日志创建失败', str(exc))
        if self.busy or self.rename_running or self.djvu_running:
            messagebox.showwarning('正在运行', '当前有任务运行，请先等待当前任务结束后再载入进度。')
            return
        try:
            with open(self.checkpoint_path(), encoding='utf-8') as f:
                payload = json.load(f)
            if str(Path(payload['folder']).resolve()) != str(Path(self.folder.get()).resolve()):
                raise ValueError('进度文件的文献目录与当前目录不一致')
            self.data.clear()
            self.order.clear()
            for row in self.tree.get_children(): self.tree.delete(row)
            for d in payload['rows']:
                if not Path(d['path']).is_file(): continue
                d = self.normalize_name_only_row(d)
                if not already_chinese_name(Path(d['path']).name):
                    d['protected'] = False
                key = str(len(self.order))
                self.order.append(key)
                self.data[key] = d
                self.tree.insert('', 'end', iid=key)
                self.refresh(key)
            self.completed_paths = set(payload.get('completed_paths', []))
            self.current_batch_paths = {self._path_key(v) for v in payload.get('pending_new_paths', []) if v}
            self.historical_paths = {self._path_key(d['path']) for d in payload['rows'] if d.get('path')}
            self.historical_paths.update(self._path_key(v) for v in payload.get('completed_paths', []) if v)
            for row in self.data.values():
                if self.missing_chinese_title(row):
                    self.completed_paths.discard(str(Path(row['path']).resolve()))
            self.active_scan_config = payload.get('scan_config')
            missing = self.audit_untranslated(silent=True)
            self.write_log(f'载入进度完成：{len(self.order)} 条，未翻译 {len(missing)} 条')
            self.status.set((f'已载入 {len(self.order)} 份历史记录；仅新增模式将跳过全部历史文件。' if self.new_files_only.get()
                             else f'已载入 {len(self.order)} 份记录；检测出 {len(missing)} 份未翻译，OCR 历史内容将复用。'))
            if missing:
                self.tree.selection_set(missing)
                self.tree.see(missing[0])
                if self.use_api.get() and self.key.get().strip():
                    if messagebox.askyesno('发现未翻译文件',
                        f'本次恢复检查出 {len(missing)} 个未取得中文书名的文件。\n'
                        '现在批量补译吗？已保存的 OCR 文本会优先复用。'):
                        self.retry_untranslated()
                else:
                    messagebox.showwarning('发现未翻译文件',
                        f'本次恢复检查出 {len(missing)} 个未取得中文书名的文件。\n'
                        '请输入 DeepSeek API Key，再点击“重试未完成翻译”。\n'
                        '原文件和历史 OCR 结果均不会被删除。')
        except FileNotFoundError:
            messagebox.showinfo('没有进度', '此目录还没有任务进度文件。')
        except Exception as exc:
            self.write_log('恢复历史进度失败：' + traceback.format_exc(), 'ERROR')
            messagebox.showerror('恢复失败', str(exc))

    def pause_job(self):
        if not self.busy: return
        self.write_log('用户请求暂停任务')
        self.resume_event.clear()
        self.pause_button.configure(state='disabled')
        self.resume_button.configure(state='normal')
        self.status.set('已请求暂停：当前文件完成后暂停。可以编辑已显示的书名。')
        self.save_checkpoint(quiet=True)

    def resume_job(self):
        if not self.busy: return
        self.write_log('用户继续任务')
        self.resume_event.set()
        self.pause_button.configure(state='normal')
        self.resume_button.configure(state='disabled')
        self.status.set('已继续处理。')

    def skip_current(self):
        if self.busy and self.job_mode in ('scan', 'retry', 'apply', 'duplicate'):
            if self.job_mode in ('scan','retry'):
                with self.active_lock:
                    # Earliest running job. Do not disturb other workers.
                    target = next(iter(self.active_files), None)
                    if target is not None: self.skip_requested.add(target)
                if target:
                    self.write_log('已请求跳过并发任务：' + target)
                    self.status.set('已请求跳过：' + Path(target).name + '；在当前不可中断步骤结束后生效。')
                    return
            self.skip_event.set()
            self.write_log('用户跳过当前文件：' + str(self.current_path))
            self.status.set('已标记跳过当前文件；当前不可中断操作结束后生效。')

    def skip_selected(self):
        if self.busy and self.resume_event.is_set():
            messagebox.showinfo('请先暂停', '扫描运行期间请先暂停，再跳过列表中选中的文件。')
            return
        selected = self.tree.selection()
        if not selected:
            return messagebox.showinfo('未选择', '请先在文件列表中选中要跳过的文献。')
        for key in selected:
            d = self.data[key]
            d['checked'] = False
            d['state'] = '人工跳过：不参与本次重命名；已扫描结果保留'
            self.refresh(key)
        self.save_checkpoint(quiet=True)
        self.status.set(f'已跳过选中的 {len(selected)} 个文件的重命名操作。')

    def worker_gate(self, path=None):
        """Cooperative pause/skip; return True when this file is to be skipped."""
        if path is not None:
            self.current_path = str(path)
        if self.skip_event.is_set():
            self.skip_event.clear()
            return True
        while not self.resume_event.wait(timeout=0.2):
            if self.skip_event.is_set():
                self.skip_event.clear()
                return True
        if self.skip_event.is_set():
            self.skip_event.clear()
            return True
        return False

    def should_skip_stage(self):
        """Skip between operations without pausing in the middle of a file."""
        if self.skip_event.is_set():
            self.skip_event.clear()
            return True
        return False

    def set_busy(self, busy):
        self.busy = busy
        self.scan_button.configure(state='disabled' if busy else 'normal')
        self.apply_button.configure(state='disabled' if busy else 'normal')
        self.retry_button.configure(state='disabled' if busy else 'normal')
        self.duplicate_button.configure(state='disabled' if busy else 'normal')
        self.pause_button.configure(state='normal' if busy and self.resume_event.is_set() else 'disabled')
        self.resume_button.configure(state='normal' if busy and not self.resume_event.is_set() else 'disabled')
        self.skip_button.configure(state='normal' if busy else 'disabled')
        if not busy:
            self.job_mode = None
            self.resume_event.set()
            self.skip_event.clear()

    @staticmethod
    def _path_key(path):
        # Stable path identity on Windows; old checkpoint and current enumeration
        # use the same normalization even when the file is missing.
        return os.path.normcase(os.path.abspath(os.path.normpath(str(path)))).casefold()

    def _history_snapshot(self, directory):
        """All previously recorded paths, even untranslated, checked=False, or skipped."""
        known = {self._path_key(r.get('path')) for r in self.data.values() if r.get('path')}
        known.update(self.historical_paths)
        known.update(self._path_key(x) for x in self.completed_paths)
        checkpoint = directory / '_整理日志' / '任务进度_v2.7.json'
        if checkpoint.is_file():
            try:
                with checkpoint.open(encoding='utf-8') as f:
                    saved = json.load(f)
                if self._path_key(saved.get('folder', '')) == self._path_key(directory):
                    known.update(self._path_key(r['path']) for r in saved.get('rows', []) if r.get('path'))
                    known.update(self._path_key(x) for x in saved.get('completed_paths', []) if x)
                else:
                    self.write_log('进度文件目录与当前目录不同；不将它作为历史基线', 'WARNING')
            except (OSError, ValueError, TypeError) as exc:
                self.write_log('读取历史索引失败；继续使用内存中的历史记录: ' + str(exc), 'WARNING')
        return known

    def start_scan(self):
        if self.busy or self.rename_running or self.djvu_running: return
        directory = Path(self.folder.get())
        if not directory.is_dir():
            messagebox.showerror('目录错误', '文件夹不存在：\n' + str(directory))
            return
        try:
            max_workers = int(self.parallel_workers.get())
            if not (1 <= max_workers <= 128): raise ValueError()
        except (ValueError, TypeError):
            messagebox.showerror('并发数错误', '同时处理数请输入 1–128 的整数；建议 4–8。')
            return
        config = {'parallel_workers': max_workers, 'folder': str(directory), 'ocr': self.use_ocr.get(), 'use_api': self.use_api.get(),
                  'key': self.key.get(), 'model': self.model.get(), 'recursive': self.recursive.get(),
                  'all_formats': self.include_nonpdf.get(),
                  'ocr_lang': 'rus+eng', 'dedupe': self.detect_duplicates.get(), 'ocr_pages': self.ocr_pages.get(), 'tail_pages': self.tail_pages.get(),
                  'ocr_mode': self.ocr_mode.get(), 'djvu_to_pdf': False,
                  'new_files_only': bool(self.new_files_only.get())}
        # Keep existing/loaded rows and skip completed paths; use a fresh scan only
        # when no previous work exists. The folder can be rescanned intentionally
        # by clearing the checkpoint file.
        try:
            self.configure_run_logger(directory)
        except Exception as exc:
            messagebox.showerror('日志初始化失败', '无法创建任务日志：' + str(exc))
            return
        if config['new_files_only']:
            config['known_paths'] = self._history_snapshot(directory)
            self.write_log('仅新增文件模式：已加载 %d 个历史路径；历史未翻译文件也将跳过。' % len(config['known_paths']))
            # Existing historical selections must never be applied by accident.
            for k in self.order:
                d = self.data[k]
                if self._path_key(d['path']) not in self.current_batch_paths:
                    d['checked'] = False
                    self.refresh(k)
        else:
            config['known_paths'] = set()
        if not config['new_files_only']:
            self.current_batch_paths = set()
        self.write_log('开始并发扫描：线程数=%s, 递归=%s, OCR=%s, DJVU仅保留原格式, 书名查重=%s, 仅新增=%s' % (max_workers, config['recursive'], config['ocr'], config['dedupe'], config['new_files_only']))
        if config['use_api'] and not config['key'].strip():
            self.write_log('未提供 API Key，外文书名将保留待补译状态；无需重复 OCR', 'WARNING')
        self.active_scan_config = {k: v for k, v in config.items() if k not in ('key', 'known_paths')}
        self.progress.set(0)
        self.resume_event.set()
        self.skip_event.clear()
        self.job_mode = 'scan'
        self.set_busy(True)
        threading.Thread(target=self.scan_worker, args=(config,), daemon=True).start()

    def _translate_limited(self, key, model, text, metadata, filename):
        self.write_log('等待API并发名额：' + filename)
        with self.api_slots:
            return translate_title(key, model, text, metadata, filename)

    def _extract_limited(self, path, **kwargs):
        # Limit expensive page rendering and child Tesseract processes.
        if kwargs.get('ocr'):
            self.write_log('等待OCR并发名额：' + Path(path).name)
            with self.ocr_slots:
                return extract_pdf(path, **kwargs)
        return extract_pdf(path, **kwargs)

    def _parallel_scan_one(self, path, config, ordinal, total):
        """Worker: CPU/IO/HTTP only. Never touch Tk or SQLite."""
        resolved = str(path.resolve())
        with self.active_lock:
            self.active_files[resolved] = time.monotonic()
        tempdir = None
        try:
            # Pause is cooperative: active operations finish, new stages wait.
            self.resume_event.wait()
            if self._parallel_skip(resolved):
                return ('skipped', resolved, None)
            self.write_log(f'[{ordinal}/{total}] 并发开始：{path.name}')
            protected = already_chinese_name(path.name)
            kind = detect_type(path)
            if kind is None and path.suffix.lower() in SUPPORTED:
                kind = path.suffix.lower()
            if kind is None or (kind != '.pdf' and not config['all_formats']):
                return ('ignored', resolved, None)
            duplicate = duplicate_of = ''
            excerpt = md = error = source = ''
            chinese = path.stem if protected else ''
            convert = False  # DJVU is NEVER converted; keep its original format
            target_ext = path.suffix  # Name-only mode never changes extensions
            if protected:
                state = '已有中文书名：跳过翻译、OCR（仍进行书名查重）'
            elif kind in ('.djvu', '.djv'):
                # First-page-only title pass, followed by front/back evidence only
                # if the first-page translation did not yield a valid Chinese name.
                self.write_log(f'DJVU未翻译书名：优先读取第一页 {path.name}')
                with self.ocr_slots:
                    excerpt, md, error = extract_first_page_title(
                        path, kind, ocr=config['ocr'], lang=config['ocr_lang'],
                        ocr_mode=config['ocr_mode'], log=self.write_log)
                source = source_title_guess(path, md, excerpt)
                if config['use_api']:
                    chinese, state = self._translate_limited(config['key'], config['model'], excerpt, md, path.name)
                else:
                    state = '等待配置API补译'
                if not chinese and config['use_api'] and config['key'] and not self._parallel_skip(resolved):
                    self.write_log(f'DJVU第一页未取得中文书名，补查书首书尾：{path.name}')
                    with self.ocr_slots:
                        more, more_md, more_status = extract_djvu(
                            path, ocr=config['ocr'], lang=config['ocr_lang'],
                            max_pages=10, tail_pages=10,
                            ocr_mode=config['ocr_mode'], log=self.write_log)
                    if more:
                        excerpt, md = more, more_md
                        source = source_title_guess(path, md, excerpt)
                        chinese, state = self._translate_limited(config['key'], config['model'], excerpt, md, path.name)
                    error = '; '.join(x for x in (error, more_status) if x)
                if error: state = error + '；' + state
                if not chinese: state = '俄文书名待补译：' + state
            elif config['use_api']:
                self.write_log(f'文件名翻译请求：{path.name} | 模型={config["model"]}')
                chinese, state = self._translate_limited(config['key'], config['model'], '', '', path.name)
                self.write_log(f'文件名翻译结果：{path.name} | 成功={bool(chinese)} | {state[:140]}')
                if chinese: state += '；按文件名翻译'
            else:
                state = '翻译未启用'
            if self._parallel_skip(resolved):
                return ('skipped', resolved, None)
            if not protected and not chinese and kind not in ('.djvu', '.djv'):
                try:
                    if kind == '.pdf':
                        self.write_log(f'文件名未译成功，优先提取PDF第一页：{path.name}')
                        excerpt, md, error = self._extract_limited(
                            path, ocr=config['ocr'], lang=config['ocr_lang'],
                            max_pages=1, tail_pages=0, ocr_mode=config['ocr_mode'])
                    else:
                        excerpt, md, error = extract_nonpdf_evidence(path, kind)
                except Exception as exc:
                    error = '第一页提取失败：' + str(exc)[:250]
                source = source_title_guess(path, md, excerpt)
                if self._parallel_skip(resolved):
                    return ('skipped', resolved, None)
                if config['use_api']:
                    self.write_log(f'第一页书名翻译请求：{path.name} | 字符={len(excerpt)}')
                    chinese, state = self._translate_limited(config['key'], config['model'], excerpt, md, path.name)
                    self.write_log(f'第一页翻译结果：{path.name} | 成功={bool(chinese)} | {state[:140]}')
                if kind == '.pdf' and not chinese and config['use_api'] and config['key'] and not self._parallel_skip(resolved):
                    self.write_log(f'PDF第一页未取得中文书名，补查书首书尾：{path.name}')
                    more, more_md, more_error = self._extract_limited(
                        path, ocr=config['ocr'], lang=config['ocr_lang'],
                        max_pages=config['ocr_pages'], tail_pages=config['tail_pages'],
                        ocr_mode=config['ocr_mode'])
                    if more:
                        excerpt, md = more, more_md
                        source = source_title_guess(path, md, excerpt)
                        chinese, state = self._translate_limited(config['key'], config['model'], excerpt, md, path.name)
                    error = '; '.join(x for x in (error, more_error) if x)
                if error: state = error + '；' + state
                if not chinese: state += '；未取得可信书名，原名保留'
            if self._parallel_skip(resolved):
                return ('skipped', resolved, None)
            ext_fix = False  # Do not change file extensions in rename-only mode
            stem = path.stem if protected else (chinese or path.stem)
            new = clean_title(stem) + target_ext
            checked = bool(not protected and complete_chinese_title(chinese) and path.name != new)
            row = {'path': str(path), 'kind': target_ext, 'source_kind': kind, 'convert': convert,
                   'source': source, 'zh': chinese, 'unverified': False,
                   'new': new, 'state': state, 'checked': checked, 'ext_fix': ext_fix,
                   'protected': protected, 'excerpt': excerpt, 'metadata': md,
                   'duplicate': duplicate, 'duplicate_of': duplicate_of}
            # Hand off tempdir to coordinator so it can reuse PDF for duplicate checks.
            t = tempdir
            tempdir = None
            return ('row', resolved, (row, t))
        except Exception as exc:
            self.write_log(f'并发单文件异常 {path.name}: {type(exc).__name__}: {exc}\n{traceback.format_exc()}', 'ERROR')
            return ('failed', resolved, str(exc))
        finally:
            if tempdir is not None:
                tempdir.cleanup()
            with self.active_lock:
                self.active_files.pop(resolved, None)
                self.skip_requested.discard(resolved)

    def _parallel_skip(self, path):
        # No abort during network requests or subprocess conversions.
        with self.active_lock:
            if path in self.skip_requested:
                self.skip_requested.discard(path)
                return True
        return False

    def scan_worker(self, config):
        """Bounded parallel workers, serialized SQLite duplicate indexing and GUI updates."""
        index = title_index = None
        cache = {}
        try:
            folder = Path(config['folder'])
            if config.get('dedupe'):
                index = Index(folder / '_整理日志' / '前十页历史指纹.sqlite')
                title_index = TitleIndex(folder / '_整理日志' / '书名历史索引.sqlite')
            paths = folder.rglob('*') if config['recursive'] else folder.iterdir()
            paths = [p for p in paths if p.is_file() and not any(k in p.parts for k in SKIP_DIRS)
                     and not p.name.lower().endswith(('.part','.tmp','.crdownload','.download'))]
            before = len(paths)
            if config.get('new_files_only'):
                old = config['known_paths']
                paths = [p for p in paths if self._path_key(p) not in old]
            # Order by modification time descending; the oldest files are processed last.
            # File-system timestamps are not necessarily download times, so this is best-effort.
            def newest_first(p):
                try: return (-p.stat().st_mtime_ns, p.name.casefold())
                except OSError: return (0, p.name.casefold())
            paths.sort(key=newest_first)
            total = len(paths)
            if config.get('new_files_only'):
                self.write_log(f'本次发现 {before} 个文件；跳过历史 {before-total} 个；新增待处理 {total} 个，按修改时间从新到旧。')
                if not config['known_paths']:
                    self.write_log('没有找到历史记录；所有当前文件将视为新增文件（按最新优先）。', 'WARNING')
            count = unresolved = duplicates = 0
            self.write_log(f'并发文件枚举完成：{total} 个；最大并发数 {config["parallel_workers"]}')
            if not total:
                self.msg.put(('finish', '没有新的待处理文件；历史文件已跳过。' if config.get('new_files_only') else '目录中没有需要扫描的文件。'))
                return
            def finish_one(result):
                nonlocal count, unresolved, duplicates
                state, resolved, payload = result
                count += 1
                if state == 'row':
                    d, temp = payload
                    d = self.normalize_name_only_row(d)
                    path = Path(d['path'])
                    kind = d['source_kind']
                    try:
                        if title_index is not None:
                            effective_title = d['zh'] or path.stem
                            matches = title_index.search(path, effective_title)
                            if matches:
                                score, reference, ref_kind = matches[0]
                                d['duplicate_of'] = reference
                                d['duplicate'] = f'书名相同/近似 {score:.0%}｜' + Path(reference).name + '（待核对内容）'
                                if kind == '.pdf' and ref_kind == '.pdf' and Path(reference).is_file():
                                    try:
                                        fp_a = index.get_or_scan(path)
                                        fp_b = index.get_or_scan(Path(reference))
                                        similarity, label = compare(fp_a, fp_b)
                                        if label:
                                            d['duplicate'] = f'书名匹配；前十页{label} {similarity:.0%}｜' + Path(reference).name
                                        else:
                                            d['duplicate'] = '书名匹配但前十页未确认相同｜' + Path(reference).name
                                    except Exception as exc:
                                        d['duplicate'] += '；内容核验失败：' + str(exc)[:110]
                                duplicates += 1
                            title_index.add(path, effective_title, kind)
                    except Exception as exc:
                        d['duplicate'] = '书名索引异常：' + str(exc)[:120]
                        self.write_log(f'查重失败 {path.name}: {exc}', 'ERROR')
                    finally:
                        if temp is not None: temp.cleanup()
                    if d['duplicate']: d['state'] += '；' + d['duplicate']
                    if not d['zh'] and not d['protected']: unresolved += 1
                    if config.get('new_files_only'):
                        self.msg.put(('new_batch_path', resolved))
                    self.msg.put(('row', d))
                    self.write_log(f'并发完成：{path.name} | 中文名={bool(d["zh"])} | 同名={bool(d["duplicate"])}')
                elif state == 'skipped':
                    self.msg.put(('skipped', resolved, '人工跳过'))
                elif state == 'failed':
                    self.write_log('单文件处理失败：' + resolved + ' | ' + str(payload), 'ERROR')
                self.msg.put(('progress', count * 100 / total, f'并发扫描 {count}/{total}，待翻译 {unresolved}，疑似重复 {duplicates}'))
            max_workers = int(config['parallel_workers'])
            max_pending = max_workers * 2
            iterator = iter(enumerate(paths,1))
            pending = {}
            with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix='VKscan') as pool:
                last_heartbeat = time.monotonic()
                while True:
                    # Submit only a bounded window; never queue thousands of background jobs.
                    while len(pending) < max_pending and self.resume_event.is_set():
                        try: ordinal, path = next(iterator)
                        except StopIteration: break
                        resolved = str(path.resolve())
                        if (not config.get('new_files_only')) and resolved in self.completed_paths:
                            finish_one(('historical', resolved, None))
                            continue
                        future = pool.submit(self._parallel_scan_one, path, config, ordinal, total)
                        pending[future] = resolved
                    if not pending:
                        if not self.resume_event.is_set():
                            self.resume_event.wait(timeout=.2)
                            continue
                        break
                    done, _ = wait(tuple(pending), timeout=.2, return_when=FIRST_COMPLETED)
                    if time.monotonic() - last_heartbeat >= 30:
                        with self.active_lock:
                            active = sorted(self.active_files.items(), key=lambda x: x[1])
                        summary = ', '.join(f'{Path(p).name} ({time.monotonic()-t:.0f}s)' for p,t in active[:6])
                        self.write_log(f'心跳：待完成={len(pending)}，正在处理={len(active)}；{summary}')
                        last_heartbeat = time.monotonic()
                    for future in done:
                        path = pending.pop(future)
                        try: result = future.result()
                        except Exception as exc:
                            self.write_log(f'调度器异常 {path}: {traceback.format_exc()}', 'ERROR')
                            result = ('failed',path,str(exc))
                        finish_one(result)
            self.msg.put(('finish', f'并发扫描完成：{total} 个文件，待翻译 {unresolved}，疑似重复 {duplicates}。'))
        except Exception as exc:
            self.write_log('并发扫描任务异常：' + traceback.format_exc(), 'ERROR')
            self.msg.put(('finish', '并发扫描失败：' + repr(exc) + '；请查看任务运行.log'))
        finally:
            for t,_ in cache.values():
                try: t.cleanup()
                except Exception: pass
            try:
                if index is not None: index.close()
                if title_index is not None: title_index.close()
            except Exception:
                self.write_log('并发索引关闭失败：' + traceback.format_exc(), 'ERROR')
    def retry_untranslated(self):
        try:
            self.configure_run_logger()
        except Exception as exc:
            messagebox.showwarning('日志创建失败', str(exc))
        if self.busy or self.rename_running or self.djvu_running:
            return
        targets = [k for k in self.order if Path(self.data[k].get('path', '')).is_file()
                   and self.missing_chinese_title(self.data[k])]
        if not targets:
            return messagebox.showinfo('待处理任务', '没有需要重试的文件。')
        if not self.key.get().strip():
            return messagebox.showwarning('缺少密钥', '请先填写 DeepSeek API Key。')
        self.job_mode = 'retry'
        self.set_busy(True)
        opts = {'ocr': self.use_ocr.get(), 'ocr_pages': self.ocr_pages.get(),
                'tail_pages': self.tail_pages.get(), 'ocr_mode': self.ocr_mode.get(),
                'parallel_workers': int(self.parallel_workers.get()) if self.parallel_workers.get().isdigit() else 4}
        threading.Thread(target=self.retry_worker,
                         args=(targets, self.key.get(), self.model.get(), opts), daemon=True).start()

    def _retry_one(self, rowkey, d, key, model, opts):
        path = Path(d['path'])
        resolved = str(path.resolve())
        with self.active_lock:
            self.active_files[resolved] = time.monotonic()
        try:
            self.resume_event.wait()
            if self._parallel_skip(resolved):
                return (rowkey, {'state': '已手动跳过；可稍后重试'}, False)
            excerpt, metadata = d.get('excerpt', ''), d.get('metadata', '')
            kind = str(d.get('source_kind') or path.suffix).lower()
            if untranslated_fragments(path.stem):
                self.write_log('检测到中文名称残留外文或原名全外文，执行补译：' + path.name)
            self.write_log(f'未翻译补译：优先读取第一页 {path.name}')
            if kind in ('.djvu', '.djv', '.pdf'):
                if opts['ocr']:
                    with self.ocr_slots:
                        first, first_md, first_status = extract_first_page_title(
                            path, kind, ocr=True, lang='rus+eng',
                            ocr_mode=opts['ocr_mode'], log=self.write_log)
                else:
                    first, first_md, first_status = extract_first_page_title(
                        path, kind, ocr=False, lang='rus+eng',
                        ocr_mode=opts['ocr_mode'], log=self.write_log)
                self.write_log(f'第一页提取：{path.name} | 字符={len(first)} | {first_status[:130]}')
            else:
                first, first_md, first_status = extract_nonpdf_evidence(path, kind)
            if self._parallel_skip(resolved):
                return (rowkey, {'state': '已手动跳过；可稍后重试'}, False)
            # Always try title from page 1 first; do not discard previously
            # cached 20-page OCR if the first page is insufficient.
            title, state = self._translate_limited(key, model, first, first_md, path.name)
            if not title and (excerpt or metadata):
                self.write_log(f'第一页未取得译名，复用历史书内文字：{path.name}')
                title, state = self._translate_limited(key, model, excerpt, metadata, path.name)
            if not title and kind in ('.pdf', '.djvu', '.djv'):
                self.write_log(f'第一页未取得译名，补查书首书尾：{path.name}')
                if kind in ('.djvu', '.djv'):
                    with self.ocr_slots:
                        more, more_md, status = extract_djvu(
                            path, ocr=opts['ocr'], lang='rus+eng', max_pages=10,
                            tail_pages=10, ocr_mode=opts['ocr_mode'], log=self.write_log)
                else:
                    more, more_md, status = self._extract_limited(
                        path, ocr=opts['ocr'], lang='rus+eng',
                        max_pages=opts['ocr_pages'], tail_pages=opts['tail_pages'],
                        ocr_mode=opts['ocr_mode'])
                if more:
                    excerpt, metadata = more, more_md
                    title, state = self._translate_limited(key, model, excerpt, metadata, path.name)
            if self._parallel_skip(resolved):
                return (rowkey, {'state': '已手动跳过；可稍后重试'}, False)
            self.write_log(f'并发补译结果：{path.name} | 首页面证据={len(first)} 字符 | 历史证据={len(excerpt)} 字符')
            info = {'state':state}
            if excerpt:
                info['excerpt'] = excerpt[:20000]
                info['metadata'] = metadata
                candidate = russian_title_candidates(excerpt)
                if candidate:
                    info['source'] = ' / '.join(candidate[:3])[:180]
            if title and complete_chinese_title(title):
                info.update({'zh':title, 'new':clean_title(title) + path.suffix, 'checked':True})
            else:
                info.update({'zh':'', 'checked':False})
                info['state'] = '仍需中文译名（不可当作完成）：' + state
            self.write_log(f'并发补译结束：{path.name} | 成功={bool(title)}')
            return (rowkey, info, complete_chinese_title(title))
        except Exception as exc:
            self.write_log(f'补译单文件异常 {path.name}: {traceback.format_exc()}', 'ERROR')
            return (rowkey, {'state':'补译异常：' + str(exc)[:180]}, False)
        finally:
            with self.active_lock:
                self.active_files.pop(resolved,None)
                self.skip_requested.discard(resolved)

    def retry_worker(self, targets, key, model, opts):
        count = done = 0
        try:
            max_workers = max(1,min(128,int(opts['parallel_workers'])))
            iterator = iter(targets)
            pending = {}
            with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix='VKretry') as pool:
                while True:
                    while len(pending) < max_workers * 2 and self.resume_event.is_set():
                        rowkey = next(iterator, None)
                        if rowkey is None: break
                        d = dict(self.data[rowkey])
                        pending[pool.submit(self._retry_one,rowkey,d,key,model,opts)] = rowkey
                    if not pending:
                        if not self.resume_event.is_set():
                            self.resume_event.wait(.2)
                            continue
                        break
                    finished, _ = wait(tuple(pending),timeout=.2,return_when=FIRST_COMPLETED)
                    for future in finished:
                        rowkey = pending.pop(future)
                        try: _,info,success = future.result()
                        except Exception as exc:
                            info,success = {'state':'补译失败：'+str(exc)[:150]},False
                        done += 1
                        count += int(success)
                        self.msg.put(('updated',rowkey,info))
                        self.msg.put(('progress',100*done/len(targets),f'并发补译 {done}/{len(targets)}，新增中文书名 {count}'))
            self.msg.put(('finish', f'并发补译完成：新增 {count} 个中文候选，未完成 {len(targets)-count} 个。'))
        except Exception as exc:
            self.write_log('补译任务异常：'+traceback.format_exc(),'ERROR')
            self.msg.put(('finish','补译失败：'+repr(exc)))

    def refresh(self, key):
        d = self.data[key]
        p = Path(d['path'])
        vals = ('✓' if d['checked'] else '', p.name, d['kind'] or '未知', d['source'], d['zh'], d['new'], d.get('duplicate', ''), d['state'])
        if self.tree.exists(key): self.tree.item(key, values=vals)

    def poll(self):
        try:
            for _ in range(80):
                item = self.msg.get_nowait()
                op = item[0]
                if op == 'log':
                    self.append_log_to_window(item[1] + '\n')
                elif op == 'row':
                    d = item[1]
                    existing = next((k for k in self.order if self.data[k].get('path') == d['path']), None)
                    if existing is not None:
                        prior = self.data[existing]
                        # Never overwrite a saved manually edited title.
                        if str(prior.get('state','')).startswith('人工修改') and prior.get('zh'):
                            d.update({k:prior[k] for k in ('zh','new','checked','state') if k in prior})
                        self.data[existing] = d
                        key = existing
                    else:
                        key = str(len(self.order))
                        self.order.append(key)
                        self.data[key] = d
                        self.tree.insert('', 'end', iid=key, values=('','', '', '', '', '', '', ''))
                    self.refresh(key)
                    if self.new_files_only.get() and self._path_key(d['path']) in self.current_batch_paths:
                        self.tree.move(key, '', 0)  # newest work stays visible above history
                    if not self.missing_chinese_title(d):
                        self.completed_paths.add(str(Path(d['path']).resolve()))
                    self.save_checkpoint(quiet=True)
                elif op == 'lane_progress':
                    lane, done, total, successes = item[1:]
                    self.rename_status.set(f'文件改名：{done}/{total}，成功 {successes}')
                elif op == 'lane_finish':
                    lane, ending = item[1], item[2]
                    self.write_log(f'{lane} 队列结束：{ending}')
                    self.rename_running = False
                    self.apply_button.configure(state='normal')
                    self.fast_apply_button.configure(state='normal')
                    self.rename_status.set('文件改名：' + ending[:110])
                    self.save_checkpoint(quiet=True, force=True)
                    if not (self.rename_running or self.djvu_running or self.busy):
                        self.offer_shutdown()
                elif op == 'new_batch_path':
                    self.current_batch_paths.add(self._path_key(item[1]))
                elif op == 'skipped':
                    # Skipped items are not marked complete: a later scan can retry them.
                    self.status.set('已跳过：' + Path(item[1]).name)
                elif op == 'progress':
                    self.progress.set(item[1])
                    self.status.set(item[2])
                elif op == 'updated':
                    key, info = item[1], item[2]
                    previous_path = self.data[key].get('path')
                    if 'path' in info and previous_path and self._path_key(previous_path) in self.current_batch_paths:
                        self.current_batch_paths.discard(self._path_key(previous_path))
                        self.current_batch_paths.add(self._path_key(info['path']))
                    self.data[key].update(info)
                    self.refresh(key)
                    self.save_checkpoint(quiet=True)
                elif op == 'finish_shutdown':
                    self.status.set(item[1])
                    self.set_busy(False)
                    self.save_checkpoint(quiet=True, force=True)
                    self.offer_shutdown()
                elif op == 'finish':
                    self.write_log(item[1])
                    self.status.set(item[1])
                    self.set_busy(False)
                    self.save_checkpoint(quiet=True, force=True)
        except queue.Empty: pass
        self.root.after(90, self.poll)

    @staticmethod
    def eligible_foreign_rename(record, new_files_only=False, current_batch_paths=None):
        """Only select a genuinely translated foreign-titled file.

        Extension-only repairs, untranslated titles, Chinese originals,
        and missing paths are intentionally excluded. Never mutate the file.
        """
        try:
            original = Path(record['path'])
            if not original.is_file():
                return False
            if record.get('protected') or already_chinese_name(original.name):
                return False
            if record.get('unverified'):
                return False
            chinese_title = str(record.get('zh') or '').strip()
            if not complete_chinese_title(chinese_title):
                return False
            proposed = Path(str(record.get('new') or ''))
            if not complete_chinese_title(proposed.stem):
                return False
            if proposed.name == original.name or proposed.name in ('', '.', '..'):
                return False
            # Respect "new files only" mode, in line with start_apply().
            if new_files_only:
                existing = current_batch_paths or set()
                if os.path.normcase(os.path.abspath(str(original))) not in existing:
                    return False
            return True
        except (OSError, ValueError, TypeError, KeyError):
            return False

    @staticmethod
    def eligible_all_actionable(record):
        """Safely include any translated filename rename only.

        A checked row still requires a separate Apply confirmation. Never change
        a file's format or extension. Skip missing, unverified, and no-op entries.
        """
        try:
            source = Path(str(record.get('path') or ''))
            if not source.is_file():
                return False
            proposed = Path(str(record.get('new') or ''))
            if proposed.name in ('', '.', '..') or not proposed.suffix:
                return False
            if record.get('convert'):
                return False  # normalize historical DJVU rows before selection
            if record.get('protected') or already_chinese_name(source.name):
                return False
            if record.get('unverified'):
                return False
            if not complete_chinese_title(record.get('zh') or ''):
                return False
            if proposed.suffix.lower() != source.suffix.lower():
                return False
            if proposed.name == source.name:
                return False
            # The existing apply worker verifies actual file format again.
            return True
        except (OSError, TypeError, ValueError):
            return False

    def select_all_actionable(self):
        """Tick all eligible visible work without executing any changes."""
        if self.busy or self.rename_running or self.djvu_running:
            messagebox.showinfo('请先结束当前任务', '当前正在扫描或修改文件。请等待任务完成后再批量勾选。')
            return
        only_new = bool(self.new_files_only.get())
        current = set(self.current_batch_paths)
        count = 0
        for key in self.order:
            row = self.normalize_name_only_row(self.data[key])
            self.data[key] = row
            if only_new and self._path_key(row['path']) not in current:
                continue
            if self.eligible_all_actionable(row):
                row['checked'] = True
                self.refresh(key)
                count += 1
        self.save_checkpoint(quiet=True, force=True)
        message = f'一键勾选完成：已勾选 {count} 项仅改名任务（DJVU保持原格式）。'
        if only_new:
            message += ' 当前仅新增模式已排除历史文件。'
        message += ' 请人工核对后使用批量改名按钮；勾选不会修改文件。'
        self.status.set(message)
        self.write_log(message)
        if count == 0:
            messagebox.showinfo('没有可勾选的项目', '请先扫描或载入进度；仅新增模式下历史文件不会勾选。')

    def select_all_foreign_renames(self):
        """Tick all safe, translated foreign-name proposals in the preview.

        Does not execute any filesystem changes; the Apply button is separate.
        """
        if self.rename_running or self.djvu_running or (self.busy and self.resume_event.is_set()):
            messagebox.showinfo('请先暂停', '扫描或重命名正在运行。请先暂停，待当前文件处理完成后再批量勾选。')
            return
        only_new = bool(self.new_files_only.get())
        current = set(self.current_batch_paths)
        chosen = 0
        for key in self.order:
            row = self.data[key]
            if self.eligible_foreign_rename(row, False):
                # Use the existing normalization method for the batch filter.
                if only_new and self._path_key(row['path']) not in current:
                    continue
                row['checked'] = True
                self.refresh(key)
                chosen += 1
        self.save_checkpoint(quiet=True, force=True)
        msg = f'已勾选 {chosen} 个具有中文译名的外语文件名候选。请人工核对后点击“应用勾选的重命名”。'
        if only_new:
            msg += ' 当前为“仅处理新增文件”模式，历史文件未勾选。'
        self.status.set(msg)
        self.write_log(msg)
        if not chosen:
            messagebox.showinfo('没有可勾选的候选', '请先扫描或载入进度，确保文件已有中文候选书名。\n如需选择历史文件，请取消“仅处理新增文件”。')

    def toggle_selected(self):
        if self.rename_running or self.djvu_running or (self.busy and self.resume_event.is_set()): return
        for key in self.tree.selection():
            if self.data[key].get('protected'):
                continue
            self.data[key]['checked'] = not self.data[key]['checked']
            self.refresh(key)

    def edit_selected(self):
        if self.rename_running or self.djvu_running or (self.busy and self.resume_event.is_set()):
            messagebox.showinfo('先暂停', '请先点击“暂停”，再修改已经扫描出的书名。')
            return
        selected = self.tree.selection()
        if len(selected) != 1:
            if not selected: messagebox.showinfo('编辑', '请先选中一行。')
            return
        key = selected[0]
        d = self.data[key]
        if d.get('protected'):
            messagebox.showinfo('无需处理', '该文件名已经含中文，程序会保留原名称，不进行 OCR、翻译或重命名。')
            return
        dialog = tk.Toplevel(self.root)
        dialog.title('核对 / 修改中文书名')
        dialog.geometry('720x295')
        dialog.transient(self.root)
        dialog.grab_set()
        ttk.Label(dialog, text='当前文件：' + Path(d['path']).name, wraplength=690).pack(anchor='w', padx=12, pady=(13, 7))
        ttk.Label(dialog, text='提取的原书名：' + (d['source'] or '无'), wraplength=690).pack(anchor='w', padx=12, pady=(0, 13))
        ttk.Label(dialog, text='修改中文书名（不含 .pdf 扩展名）：').pack(anchor='w', padx=12)
        var = tk.StringVar(value=d['zh'])
        ent = ttk.Entry(dialog, textvariable=var, width=85)
        ent.pack(fill='x', padx=12, pady=8)
        ent.focus_set()
        def save():
            value = clean_title(var.get())
            d['zh'] = value
            d['new'] = (value or Path(d['path']).stem) + d['kind']
            d['checked'] = bool(d['new'] != Path(d['path']).name)
            d['unverified'] = False
            d['state'] = '人工修改中文书名，待应用' if value else '已清空中文书名，仅修复扩展名'
            self.refresh(key)
            self.save_checkpoint(quiet=True)
            dialog.destroy()
        ttk.Button(dialog, text='保存候选书名', command=save).pack(pady=14)

    def lane_control(self, lane, action):
        if lane not in ('rename', 'djvu'):
            return
        if not getattr(self, lane + '_running'):
            return
        resume = getattr(self, lane + '_resume')
        skip = getattr(self, lane + '_skip')
        if action == 'pause':
            resume.clear()
        elif action == 'resume':
            resume.set()
        elif action == 'skip':
            # Cooperative skip takes effect at the next file boundary.
            skip.set()
        self.write_log(f'{lane} 队列控制：{action}')

    def lane_gate(self, lane):
        resume = getattr(self, lane + '_resume')
        skip = getattr(self, lane + '_skip')
        while not resume.wait(0.2):
            # An operator can resume and skip without interrupting a conversion.
            pass
        if skip.is_set():
            skip.clear()
            return True
        return False

    def _selected_lane(self, lane):
        if lane != 'rename':
            return []
        rows = []
        for key in self.order:
            d = self.normalize_name_only_row(self.data[key])
            self.data[key] = d
            src = Path(d.get('path', ''))
            if not d.get('checked') or not src.is_file():
                continue
            if self.new_files_only.get() and self._path_key(str(src)) not in self.current_batch_paths:
                continue
            if d.get('protected') or already_chinese_name(src.name):
                continue
            if not complete_chinese_title(d.get('zh') or ''):
                continue
            if src.name == d.get('new'):
                continue
            rows.append((key, dict(d)))
        return rows

    def _lane_worker_entry(self, selected, fast_only, lane):
        try:
            self.apply_worker(selected, fast_only, lane)
        except Exception:
            error = traceback.format_exc()
            self.write_log(f'{lane} 队列意外退出：{error}', 'ERROR')
            self.msg.put(('lane_finish', lane, '异常中止；请查看实时任务日志'))

    def start_fast_apply(self):
        """Apply only normal filename changes, bypassing costly DJVU/PDF conversion."""
        if self.busy or self.rename_running:
            return
        selected = self._selected_lane('rename')
        if not selected:
            messagebox.showinfo('没有快速改名任务', '当前没有已勾选且取得中文译名的待改名文件。')
            return
        if not messagebox.askyesno('快速批量改名',
                                   f'将快速修改 {len(selected)} 个现有文件的名字。\n'
                                   '不运行 OCR、DeepSeek、查重或 DJVU 转换。\n'
                                   '仍检查文件真实扩展名、目标重名与源文件是否存在。\n'
                                   'DJVU保留原扩展名，只修改中文文件名。\n\n确定继续？'):
            return
        self.rename_running = True
        self.rename_resume.set(); self.rename_skip.clear()
        self.rename_status.set(f'普通改名：0/{len(selected)}')
        self.apply_button.configure(state='disabled')
        self.fast_apply_button.configure(state='disabled')
        threading.Thread(target=self._lane_worker_entry, args=(selected, True, 'rename'), daemon=True).start()

    def start_apply(self):
        """A name-only queue for all files, including DJVU without conversion."""
        if self.busy or self.rename_running:
            return
        selected = self._selected_lane('rename')
        if not selected:
            messagebox.showinfo('没有改名任务', '没有取得有效中文译名的待改名文件。')
            return
        if not messagebox.askyesno('批量普通改名',
             f'只修改 {len(selected)} 个文献的文件名（包含DJVU）；绝不转换格式。\n确定继续？'):
            return
        self.rename_running = True
        self.rename_resume.set(); self.rename_skip.clear()
        self.rename_status.set(f'普通改名：0/{len(selected)}')
        self.apply_button.configure(state='disabled')
        self.fast_apply_button.configure(state='disabled')
        self.write_log(f'仅改名队列启动，共 {len(selected)} 个任务；包含DJVU原格式')
        threading.Thread(target=self._lane_worker_entry, args=(selected,True,'rename'), daemon=True).start()

    def apply_worker(self, selected, fast_only=False, lane="rename"):
        folder = Path(self.folder.get())
        logdir = folder / '_整理日志'
        stamp = dt.datetime.now().strftime('%Y%m%d_%H%M%S')
        rows = []
        reserved = set()
        successes = 0
        start_at = time.monotonic()
        index_changes = 0
        index = None
        try:
            # Fast mode never creates a new fingerprint database just to rename files.
            dbfile = folder / '_整理日志' / '前十页历史指纹.sqlite'
            if not fast_only or dbfile.is_file():
                index = Index(dbfile)
        except Exception:
            pass
        for i, (key, d) in enumerate(selected, 1):
            if self.lane_gate(lane):
                self.msg.put(('updated', key, {'state': '手动跳过本次'+('转换' if lane=='djvu' else '改名')}))
                continue
            d = self.normalize_name_only_row(d)
            src = Path(d['path'])
            dst = ''
            result = ''
            target = None
            try:
                if not src.is_file():
                    raise FileNotFoundError('源文件已经不存在')
                if already_chinese_name(src.name):
                    result = '跳过：原文件已有中文名称'
                    self.msg.put(('updated', key, {'checked': False, 'state': result}))
                    rows.append({'time': dt.datetime.now().isoformat(timespec='seconds'), 'old_path': str(src),
                                 'new_path': str(src), 'detected_ext': d['kind'], 'source_title': d['source'],
                                 'zh_title': d['zh'], 'result': result})
                    self.msg.put(('lane_progress', lane, i, len(selected), successes))
                    continue
                proposed = clean_title(d['zh']) if d['zh'] else src.stem
                with self.destination_mutex:
                    target = unique_destination(src, proposed, d['kind'], self.destination_reservations)
                # Only an in-place filename change is allowed, even for DJVU.
                if src != target:
                    actual=detect_type(src)
                    if actual=='.djvu' and target.suffix.lower()=='.pdf':
                        raise ValueError('安全机制：禁止直接将DJVU改名成PDF')
                    if actual and target.suffix.lower()!=actual and not (actual == '.djvu' and target.suffix.lower() == '.djv'):
                        raise ValueError('目标后缀与文件真实格式不匹配：'+actual)
                    src.rename(target)
                    if index is not None:
                        try:
                            with self.index_mutex:
                                index.moved(src, target, commit=True)
                        except Exception as index_exc:
                            # The filesystem rename has succeeded. A stale optional
                            # fingerprint index is not a rename failure.
                            self.write_log('文件已改名，查重索引更新失败（可重新扫描索引）：' + str(index_exc), 'WARNING')
                dst = str(target)
                successes += 1
                result = '成功'
                self.msg.put(('updated', key, {'path': dst, 'new': target.name, 'checked': False, 'state': '已重命名'}))
            except Exception as exc:
                result = '失败：' + str(exc)
                self.msg.put(('updated', key, {'state': result}))
            finally:
                if target is not None:
                    with self.destination_mutex:
                        self.destination_reservations.discard(str(target).casefold())
            rows.append({'time': dt.datetime.now().isoformat(timespec='seconds'), 'old_path': str(src),
                         'new_path': dst, 'detected_ext': d['kind'], 'source_title': d['source'],
                         'zh_title': d['zh'], 'result': result})
            self.msg.put(('lane_progress', lane, i, len(selected), successes))
        try:
            logdir.mkdir(parents=True, exist_ok=True)
            path = logdir / f'普通改名_日志_{stamp}.csv'
            with open(path, 'w', encoding='utf-8-sig', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=list(rows[0]) if rows else ['time', 'old_path', 'new_path', 'detected_ext', 'source_title', 'zh_title', 'result'])
                writer.writeheader()
                writer.writerows(rows)
            ending = f'完成：成功 {successes}/{len(selected)}。日志：{path}'
        except Exception as exc:
            ending = f'完成：成功 {successes}/{len(selected)}，但日志保存失败：{exc}'
        if index is not None:
            try:
                with self.index_mutex: index.db.commit()
            finally:
                index.close()
        if fast_only:
            elapsed = max(0.001, time.monotonic() - start_at)
            ending += f'；快速改名耗时 {elapsed:.1f} 秒，平均 {successes / elapsed:.1f} 个/秒。'
        self.msg.put(('lane_finish', lane, ending))

    def start_pdf_audit(self):
        if self.busy or self.rename_running or self.djvu_running:
            messagebox.showwarning('任务运行中','请先结束当前任务，再检查PDF。')
            return
        folder=Path(self.folder.get())
        if not folder.is_dir():
            messagebox.showerror('目录不存在',str(folder));return
        if not messagebox.askyesno('检查异常PDF','将批量验证PDF文件头和每一页。不会改动任何文献。是否开始？'):
            return
        recursive=bool(self.recursive.get())
        self.set_busy(True)
        threading.Thread(target=self.pdf_audit_worker,args=(folder,recursive),daemon=True).start()

    def pdf_audit_worker(self,folder,recursive):
        try:
            files=sorted(folder.rglob('*.pdf') if recursive else folder.glob('*.pdf'))
            logdir=folder/'_整理日志';logdir.mkdir(parents=True,exist_ok=True)
            report=logdir/('PDF安全检查_'+dt.datetime.now().strftime('%Y%m%d_%H%M%S')+'.csv')
            errors=0
            with report.open('w',encoding='utf-8-sig',newline='') as fp:
                writer=csv.writer(fp);writer.writerow(['路径','状态','页数','详细原因'])
                for i,path in enumerate(files,1):
                    try:
                        n=validate_real_pdf(path);status='正常';reason=''
                    except Exception as exc:
                        n='';status='异常';reason=str(exc);errors+=1
                        self.write_log('异常PDF：'+str(path)+'；'+reason,'WARNING')
                    writer.writerow([str(path),status,n,reason])
                    if i%5==0 or status=='异常' or i==len(files):
                        self.msg.put(('progress',i*100/max(1,len(files)),f'PDF检查{i}/{len(files)}，异常{errors}'))
            self.write_log('PDF检查完成，异常%d，报告：%s'%(errors,report))
            self.msg.put(('finish',f'检查完成，共{len(files)}份，异常{errors}份。报告：{report}'))
        except Exception:
            self.write_log('PDF安全检查错误：'+traceback.format_exc(),'ERROR')
            self.msg.put(('finish','PDF检查出错，请查看任务日志'))

    def start_move_duplicates(self):
        if self.busy or self.rename_running or self.djvu_running:
            return
        # A duplicate candidate is moved; the reference/master remains where it is.
        candidates = [(key, dict(self.data[key])) for key in self.order
                      if self.data[key].get('duplicate_of')
                      and (not self.new_files_only.get() or self._path_key(self.data[key]['path']) in self.current_batch_paths)
                      and not
                      self.data[key].get('state', '').startswith(('已移动', '人工跳过'))]
        if not candidates:
            return messagebox.showinfo('查重', '没有检测到疑似重复文件。请先启用“前十页内容查重”并扫描。')
        folder = Path(self.folder.get()).resolve()
        target_dir = folder / '疑似重复文献'
        msg = (f'将 {len(candidates)} 个疑似重复文献移动到：\n{target_dir}\n\n'
               '同名不等于内容相同！对于未通过前十页确认的候选也会显示在列表中，请逐项核对后再移动。不会删除原文件。')
        if not messagebox.askyesno('确认移动疑似重复文献', msg):
            return
        self.job_mode = 'duplicate'
        self.set_busy(True)
        threading.Thread(target=self.move_duplicates_worker, args=(candidates, folder, target_dir), daemon=True).start()

    def move_duplicates_worker(self, candidates, folder, target_dir):
        successes = 0
        logrows = []
        index = None
        try:
            target_dir.mkdir(parents=True, exist_ok=True)
            index = Index(folder / '_整理日志' / '前十页历史指纹.sqlite')
            for i, (key, d) in enumerate(candidates, 1):
                if self.worker_gate(d['path']):
                    self.msg.put(('updated', key, {'state': '已跳过本次移动'}))
                    continue
                d = self.normalize_name_only_row(d)
                src = Path(d['path'])
                try:
                    if not src.exists():
                        raise FileNotFoundError('源文件不存在')
                    if src.resolve().parent == target_dir.resolve():
                        raise ValueError('文件已在重复文献目录')
                    # Never move a file that is referenced as the source of another match.
                    # A conservative rule: only move if reference file exists outside duplicates.
                    reference = Path(d['duplicate_of'])
                    if not reference.is_file() or reference.resolve().parent == target_dir.resolve():
                        raise ValueError('原始参考文件已不存在或不在主目录，请人工核对')
                    if reference.resolve() == src.resolve():
                        raise ValueError('不能移动参考原件')
                    # Translate/rename duplicate candidates before they enter the separate folder.
                    target_stem = clean_title(d.get('zh') or src.stem) or src.stem
                    dest = target_dir / (target_stem + d['kind'])
                    suffix = 2
                    while dest.exists():
                        dest = target_dir / (target_stem + f' ({suffix})' + d['kind'])
                        suffix += 1
                    if detect_type(src)=='.djvu' and dest.suffix.lower()=='.pdf':
                        raise ValueError('安全机制：禁止直接将DJVU改名成PDF')
                    shutil.move(str(src),str(dest))
                    index.moved(src, dest)
                    successes += 1
                    self.msg.put(('updated', key, {'path': str(dest), 'checked': False,
                                  'state': '已移动到疑似重复文献', 'new': dest.name}))
                    result = '已移动'
                except Exception as exc:
                    result = '未移动：' + str(exc)
                    self.msg.put(('updated', key, {'state': result}))
                logrows.append([str(src), result, d['duplicate_of'], d.get('duplicate', '')])
                self.msg.put(('progress', i * 100 / len(candidates), f'移动疑似重复 {i}/{len(candidates)}，成功 {successes}'))
            with open(folder / '_整理日志' / ('疑似重复移动_' + dt.datetime.now().strftime('%Y%m%d_%H%M%S') + '.csv'),
                      'w', encoding='utf-8-sig', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['来源', '结果', '参考文件', '相似度依据'])
                writer.writerows(logrows)
            self.msg.put(('finish_shutdown', f'重复文件整理完成：移动 {successes}/{len(candidates)}。目录：{target_dir}'))
        except Exception as exc:
            self.msg.put(('finish', '移动重复文件异常：' + str(exc)))
        finally:
            if index is not None:
                index.close()

    def offer_shutdown(self):
        if not self.shutdown_after.get():
            return
        if not messagebox.askyesno('自动关机确认',
            '整理操作已结束。是否在 120 秒后关闭 Windows？\n'
            '请先保存其他程序中的工作。可在 PowerShell 中执行 shutdown /a 撤销。'):
            return
        try:
            sysroot = os.environ.get('SystemRoot', r'C:\Windows')
            exe = str(Path(sysroot) / 'System32' / 'shutdown.exe')
            subprocess.run([exe, '/s', '/t', '120'], check=True, capture_output=True, timeout=15)
            messagebox.showinfo('已安排关机', 'Windows 将在 120 秒后关机。\n取消命令：shutdown /a')
        except Exception as exc:
            messagebox.showerror('自动关机未启动', str(exc))

    def export_csv(self):
        if not self.order: return messagebox.showinfo('没有数据', '请先扫描。')
        filepath = filedialog.asksaveasfilename(defaultextension='.csv', filetypes=[('CSV', '*.csv')],
                                                  initialfile='文献整理预览.csv')
        if not filepath: return
        try:
            with open(filepath, 'w', encoding='utf-8-sig', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['选择', '原文件完整路径', '识别格式', '原书名', '中文候选书名', '拟改为', '重复检测', '状态'])
                for key in self.order:
                    d = self.data[key]
                    writer.writerow(['是' if d['checked'] else '否', d['path'], d['kind'], d['source'], d['zh'], d['new'], d.get('duplicate', ''), d['state']])
            self.status.set('已保存预览：' + filepath)
        except Exception as exc:
            messagebox.showerror('写入失败', str(exc))


if __name__ == '__main__':
    root = tk.Tk()
    try:
        ttk.Style().theme_use('clam')
    except tk.TclError:
        pass
    App(root)
    root.mainloop()
