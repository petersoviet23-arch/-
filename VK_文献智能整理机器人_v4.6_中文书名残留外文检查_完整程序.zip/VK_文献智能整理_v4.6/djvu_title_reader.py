# -*- coding: utf-8 -*-
"""Read DJVU first/last pages without converting the book to PDF.

Uses DjVuLibre CLI for page count, OCR text layer and individual TIFF page
rendering. All temporary images are discarded; source DJVU is never modified.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path


def locate_tool(tool):
    executable = tool + ('.exe' if os.name == 'nt' else '')
    names = [os.environ.get('DJVU_LIBRE_DIR', ''),
             os.environ.get('ProgramFiles(x86)', r'C:\Program Files (x86)'),
             os.environ.get('ProgramFiles', r'C:\Program Files'),
             r'C:\Program Files (x86)', r'C:\Program Files']
    candidates = [shutil.which(tool), shutil.which(executable)]
    for root in names:
        if root:
            base = Path(root)
            candidates += [base / executable, base / 'DjVuLibre' / executable,
                           base / 'DjVuLibre' / 'bin' / executable,
                           base / 'DjVuLibre' / 'DjView' / executable]
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return str(candidate)
    return None


def _run(args, timeout=60):
    # Never use shell=True; arguments preserve Unicode paths on Windows.
    return subprocess.run([str(x) for x in args], capture_output=True,
                          timeout=timeout, check=False)


def _decode(raw):
    for codec in ('utf-8-sig', 'utf-8', 'cp1251'):
        try:
            return raw.decode(codec)
        except UnicodeDecodeError:
            pass
    return raw.decode('utf-8', errors='replace')


def _page_count(path, djvused):
    result = _run([djvused, str(path), '-e', 'n'], timeout=35)
    if result.returncode:
        raise RuntimeError('读取DJVU总页数失败：' + _decode(result.stderr)[:150])
    match = re.search(r'\b(\d+)\b', _decode(result.stdout))
    if not match or int(match.group(1)) <= 0:
        raise RuntimeError('DJVU总页数无效')
    return int(match.group(1))


def _selected(total, front, back):
    front = max(1, min(int(front), 30))
    back = max(0, min(int(back), 30))
    return sorted(set(range(1, min(front, total) + 1)) |
                  set(range(max(1, total - back + 1), total + 1)))


def extract_djvu(path, ocr=True, lang='rus+eng', max_pages=10,
                 tail_pages=10, ocr_mode='auto', log=None):
    """Return (excerpt, metadata, status). Excerpt is safe to cache in JSON.

    `ocr=False` extracts only the existing DjVu text layer.
    `ocr_mode=all` runs OCR even for pages with a text layer.
    """
    source = Path(path)
    count_tool = locate_tool('djvused')
    text_tool = locate_tool('djvutxt')
    renderer = locate_tool('ddjvu') if ocr else None
    if not count_tool:
        return '', '', '缺少DjVuLibre djvused.exe，无法检查DJVU首页和末页'
    try:
        total = _page_count(source, count_tool)
        pages = _selected(total, max_pages, tail_pages)
    except (OSError, ValueError, subprocess.TimeoutExpired, RuntimeError) as exc:
        return '', '', 'DJVU页面索引失败：' + str(exc)[:180]
    if log:
        log(f'DJVU首尾识别：{source.name} | 总页数={total} | 本次检查={len(pages)}页')
    tesseract = tessdata = None
    messages = []
    if ocr:
        candidates = [os.environ.get('TESSERACT_EXE'), shutil.which('tesseract'),
                      Path(os.environ.get('ProgramFiles', r'C:\Program Files')) / 'Tesseract-OCR' / 'tesseract.exe',
                      Path(os.environ.get('ProgramFiles(x86)', r'C:\Program Files (x86)')) / 'Tesseract-OCR' / 'tesseract.exe']
        for c in candidates:
            if c and Path(c).is_file():
                tesseract = str(c)
                break
        if not tesseract:
            messages.append('未找到Tesseract，尝试只读取DJVU文字层')
        else:
            tessdata = str(Path(os.environ.get('LOCALAPPDATA', '')) /
                           'VKLibraryOrganizer' / 'OCR' / 'tessdata')
            if not Path(tessdata).is_dir():
                tessdata = str(Path(tesseract).parent / 'tessdata')
            try:
                langs = _run([tesseract, '--tessdata-dir', tessdata, '--list-langs'], timeout=15)
                found = set(re.findall(r'(?m)^([a-z][a-z_0-9]+)\s*$',
                                   _decode(langs.stdout + b'\n' + langs.stderr)))
                missing = set(lang.split('+')) - found
                if missing:
                    messages.append('Tesseract缺少语言包：' + ', '.join(sorted(missing)))
                    tesseract = None
            except (OSError, subprocess.TimeoutExpired) as exc:
                messages.append('OCR环境检测失败：' + str(exc)[:100])
                tesseract = None
    if ocr and not renderer:
        messages.append('未找到ddjvu.exe，无法执行单页OCR')
    excerpts = []
    success_ocr = 0
    for page in pages:
        text = ''
        if text_tool:
            try:
                result = _run([text_tool, f'-page={page}', str(source)], timeout=45)
                if result.returncode == 0:
                    text = _decode(result.stdout).strip()
                else:
                    messages.append(f'第{page}页文本层提取失败')
            except (OSError, subprocess.TimeoutExpired) as exc:
                messages.append(f'第{page}页文本层异常：{str(exc)[:60]}')
        needs_ocr = bool(ocr and tesseract and renderer and
                         (ocr_mode == 'all' or len(re.sub(r'\s+', '', text)) < 100))
        if needs_ocr:
            try:
                with tempfile.TemporaryDirectory(prefix='vk_djvu_page_') as temp:
                    tiff = Path(temp) / 'page.tif'
                    result = _run([renderer, '-format=tiff', '-scale=125',
                                   f'-page={page}', str(source), str(tiff)], timeout=100)
                    if result.returncode != 0 or not tiff.exists() or tiff.stat().st_size < 100:
                        raise RuntimeError('页图像解码失败：' + _decode(result.stderr)[:80])
                    ocr_result = _run([tesseract, str(tiff), 'stdout', '--tessdata-dir',
                                       tessdata, '-l', lang, '--psm', '3'], timeout=120)
                    if ocr_result.returncode != 0:
                        raise RuntimeError('Tesseract OCR 返回码 ' + str(ocr_result.returncode))
                    recognized = _decode(ocr_result.stdout).strip()
                    if len(recognized) > len(text) or ocr_mode == 'all':
                        text = recognized or text
                    success_ocr += 1
            except (OSError, ValueError, subprocess.TimeoutExpired, RuntimeError) as exc:
                messages.append(f'第{page}页OCR失败：{str(exc)[:85]}')
        if text.strip():
            region = '开头' if page <= int(max_pages) else '结尾'
            excerpts.append((region, f'[全书{total}页 | {region}第{page}页]\n{text[:1800]}'))
    head = '\n\n'.join(text for region, text in excerpts if region == '开头')[:11500]
    tail = '\n\n'.join(text for region, text in excerpts if region == '结尾')[:11500]
    combined = (head + '\n\n' + tail).strip()
    status = f'DJVU已检查前{min(int(max_pages),total)}页和后{min(int(tail_pages),total)}页；文本层={"可用" if text_tool else "不可用"}；OCR完成{success_ocr}页'
    if messages:
        status += '；' + '; '.join(messages[:4])
    if log:
        log(f'DJVU提取结束：{source.name} | 证据字符={len(combined)} | OCR页数={success_ocr}')
    return combined, '', status
