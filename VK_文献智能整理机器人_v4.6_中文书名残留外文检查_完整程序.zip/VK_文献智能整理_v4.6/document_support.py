# -*- coding: utf-8 -*-
"""Read-only document metadata extraction and PDF validation.

This release does not include or invoke a DJVU-to-PDF conversion engine.
"""
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree


def extract_nonpdf_evidence(path, kind):
    """Best-effort evidence from selected non-PDF formats, no OCR claimed."""
    path = Path(path)
    try:
        if kind == '.txt':
            raw = path.read_bytes()[:45000]
            for enc in ('utf-8-sig', 'cp1251', 'utf-16'):
                try: return raw.decode(enc)[:12000], '', ''
                except UnicodeError: pass
        if kind == '.docx':
            with zipfile.ZipFile(path) as z:
                xml = z.read('word/document.xml')
                root = ElementTree.fromstring(xml)
                pieces = [x.text for x in root.iter() if x.tag.endswith('}t') and x.text]
                return ' '.join(pieces)[:12000], '', ''
        if kind == '.epub':
            with zipfile.ZipFile(path) as z:
                names = [x for x in z.namelist() if x.lower().endswith(('.opf','.xhtml','.html','.htm'))]
                pieces = []
                for name in names[:8]:
                    raw = z.read(name)[:45000].decode('utf-8', errors='replace')
                    text = re.sub(r'<[^>]*>', ' ', raw)
                    pieces.append(re.sub(r'\s+', ' ', text)[:2500])
                return '\n'.join(pieces)[:12000], '', ''
        if kind == '.fb2':
            data = path.read_bytes()[:100000]
            for enc in ('utf-8-sig', 'cp1251'):
                try:
                    raw = data.decode(enc)
                    txt = re.sub(r'<[^>]*>', ' ', raw)
                    return re.sub(r'\s+', ' ', txt)[:12000], '', ''
                except UnicodeDecodeError: pass
    except Exception as exc:
        return '', '', '无法读取正文：' + str(exc)[:120]
    return '', '', '该格式仅依据文件名翻译；如书名无意义，可手动编辑'


def validate_real_pdf(path):
    """Strict read-only PDF check. Refuse disguised files."""
    import pymupdf
    path = Path(path)
    if not path.is_file() or path.stat().st_size < 128:
        raise ValueError('文件不存在或体积异常')
    with path.open('rb') as f:
        magic = f.read(32)
    if not magic.startswith(b'%PDF-'):
        if magic.startswith(b'AT&TFORM') or (magic.startswith(b'FORM') and b'DJV' in magic):
            raise ValueError('文件实际为DJVU，不能只将后缀改成PDF')
        raise ValueError('文件头不是PDF')
    try:
        with pymupdf.open(str(path)) as doc:
            if not doc.is_pdf or doc.needs_pass or len(doc) == 0:
                raise ValueError('加密、无页或非PDF')
            for i in range(len(doc)):
                page=doc.load_page(i)
                if page.rect.is_empty or page.rect.is_infinite:
                    raise ValueError(f'第{i+1}页页面尺寸异常')
            return len(doc)
    except Exception as exc:
        raise ValueError('PDF页面检查失败：'+str(exc)) from exc


